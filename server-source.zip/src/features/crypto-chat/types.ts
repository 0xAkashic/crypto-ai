"use client";

export type MessageRole = "user" | "assistant";

export interface ChatMessage {
  id: string;
  role: MessageRole;
  content: string;
  timestamp: Date;
  isStreaming?: boolean;
  tokenData?: TokenData | null;
}

export interface ChatSession {
  id: string;
  title: string;
  messages: ChatMessage[];
  createdAt: Date;
  updatedAt: Date;
}

export interface TokenData {
  id: string;
  symbol: string;
  name: string;
  current_price: number;
  price_change_percentage_24h: number;
  market_cap: number;
  total_volume: number;
  image?: string;
}

export interface ChatRequest {
  messages: Array<{ role: MessageRole; content: string }>;
}

export interface ChatResponse {
  content: string;
  tokenData?: TokenData | null;
}

export type AIMode = "normal" | "trader" | "analyst" | "defi" | "nft" | "educator";

export const AI_MODES: Record<AIMode, { icon: string; label: string }> = {
  normal: { icon: "💬", label: "Chat" },
  trader: { icon: "📈", label: "Trader" },
  analyst: { icon: "📊", label: "Analyst" },
  defi: { icon: "🏦", label: "DeFi" },
  nft: { icon: "🎨", label: "NFT" },
  educator: { icon: "🎓", label: "Learn" },
};

export const SUGGESTED_PROMPTS = [
  "What is the BTC price now?",
  "Write a REST API in Python FastAPI",
  "Explain DeFi yield farming simply",
  "How far is Earth from the Sun?",
  "Reverse a string in JavaScript",
  "What is Bitcoin halving?",
  "Why is SOL pumping today?",
  "Fix this: TypeError: cannot read property",
];
