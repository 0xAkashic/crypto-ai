"use client";

import { useState, useRef, useEffect, useCallback } from "react";
import dynamic from "next/dynamic";
import { ChatMessage, ChatSession } from "@/features/crypto-chat/types";
import { MessageBubble } from "@/features/crypto-chat/components/message-bubble";
import { ChatInput } from "@/features/crypto-chat/components/chat-input";
import { MarketTicker } from "@/features/crypto-chat/components/market-ticker";
import { ShareButton } from "@/neynar-farcaster-sdk/mini";

// SSR disabled — SuggestedPrompts uses animations + browser APIs that cause hydration mismatches
const SuggestedPrompts = dynamic(
  () => import("@/features/crypto-chat/components/suggested-prompts").then((m) => m.SuggestedPrompts),
  {
    ssr: false,
    loading: () => (
      <div className="flex flex-col items-center justify-center py-16 gap-3">
        <div className="w-12 h-12 rounded-2xl bg-white/5 animate-pulse" />
        <div className="h-4 w-32 bg-white/5 rounded-full animate-pulse" />
        <div className="h-3 w-48 bg-white/5 rounded-full animate-pulse mt-1" />
      </div>
    ),
  }
);

function generateId(): string {
  return Math.random().toString(36).substring(2, 11);
}

function createSession(): ChatSession {
  return {
    id: generateId(),
    title: "New Chat",
    messages: [],
    createdAt: new Date(),
    updatedAt: new Date(),
  };
}

export function ChatScreen() {
  const [session, setSession] = useState<ChatSession>(createSession);
  const [isLoading, setIsLoading] = useState(false);
  const [showHistory, setShowHistory] = useState(false);
  const [sessions, setSessions] = useState<ChatSession[]>([]);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const messagesContainerRef = useRef<HTMLDivElement>(null);
  // Ref to always have latest session inside async callbacks (no stale closure)
  const sessionRef = useRef<ChatSession>(session);

  // Keep ref in sync with latest state
  useEffect(() => { sessionRef.current = session; }, [session]);

  // Scroll to bottom on new messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [session.messages]);

  // Save session to history when messages are added
  useEffect(() => {
    if (session.messages.length > 0) {
      setSessions((prev) => {
        const existing = prev.findIndex((s) => s.id === session.id);
        if (existing >= 0) {
          const updated = [...prev];
          updated[existing] = session;
          return updated;
        }
        return [session, ...prev];
      });
    }
  }, [session]);

  const sendMessage = useCallback(
    async (content: string) => {
      if (isLoading) return;

      // Always read latest session from ref — avoids stale closure bug
      const currentSession = sessionRef.current;

      const userMessage: ChatMessage = {
        id: generateId(),
        role: "user",
        content,
        timestamp: new Date(),
      };

      const assistantMessage: ChatMessage = {
        id: generateId(),
        role: "assistant",
        content: "",
        timestamp: new Date(),
        isStreaming: true,
      };

      // Update title from first message
      const isFirstMessage = currentSession.messages.length === 0;
      const newTitle = isFirstMessage
        ? content.slice(0, 40) + (content.length > 40 ? "..." : "")
        : currentSession.title;

      setSession((prev) => ({
        ...prev,
        title: newTitle,
        messages: [...prev.messages, userMessage, assistantMessage],
        updatedAt: new Date(),
      }));
      setIsLoading(true);

      try {
        const historyForApi = currentSession.messages.map((m) => ({
          role: m.role,
          content: m.content,
        }));

        const response = await fetch("/api/crypto-chat", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            messages: [...historyForApi, { role: "user", content }],
          }),
        });

        if (!response.ok) {
          throw new Error(`HTTP ${response.status}`);
        }

        const reader = response.body?.getReader();
        const decoder = new TextDecoder();

        if (!reader) throw new Error("No response stream");

        let fullContent = "";
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        let tokenData: any = null;
        let streamDone = false;
        let buffer = "";

        while (!streamDone) {
          const { done, value } = await reader.read();
          if (done) break;

          buffer += decoder.decode(value, { stream: true });
          const lines = buffer.split("\n");
          buffer = lines.pop() ?? "";

          for (const line of lines) {
            if (!line.startsWith("data: ")) continue;
            const data = line.slice(6).trim();
            if (data === "[DONE]") { streamDone = true; break; }
            if (!data) continue;

            try {
              const parsed = JSON.parse(data);
              if (parsed.type === "text") {
                fullContent += parsed.content;
                setSession((prev) => ({
                  ...prev,
                  messages: prev.messages.map((m) =>
                    m.id === assistantMessage.id
                      ? { ...m, content: fullContent, isStreaming: true }
                      : m
                  ),
                }));
              } else if (parsed.type === "token_data") {
                tokenData = parsed.data;
              }
            } catch {
              // Skip malformed lines
            }
          }
        }

        // Finalize message
        setSession((prev) => ({
          ...prev,
          messages: prev.messages.map((m) =>
            m.id === assistantMessage.id
              ? { ...m, content: fullContent, isStreaming: false, tokenData }
              : m
          ),
          updatedAt: new Date(),
        }));
      } catch (error) {
        const errMsg =
          error instanceof Error ? error.message : "Something went wrong";
        setSession((prev) => ({
          ...prev,
          messages: prev.messages.map((m) =>
            m.id === assistantMessage.id
              ? {
                  ...m,
                  content: `Sorry, I ran into an issue: ${errMsg}. Please try again.`,
                  isStreaming: false,
                }
              : m
          ),
        }));
      } finally {
        setIsLoading(false);
      }
    },
    [isLoading]
  );

  function startNewChat() {
    setSession(createSession());
    setShowHistory(false);
  }

  function loadSession(s: ChatSession) {
    setSession(s);
    setShowHistory(false);
  }

  const hasMessages = session.messages.length > 0;

  return (
    <div className="h-full flex flex-col overflow-hidden" style={{ background: "#050511" }}>
      {/* Header */}
      <header
        className="shrink-0 px-4 pt-3 pb-2"
        style={{
          borderBottom: "1px solid rgba(255,255,255,0.06)",
          background: "rgba(5,5,17,0.9)",
          backdropFilter: "blur(20px)",
        }}
      >
        {/* Top row */}
        <div className="flex items-center justify-between mb-2.5">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowHistory(!showHistory)}
              className="w-9 h-9 rounded-xl flex items-center justify-center transition-all duration-200 active:scale-90"
              style={{
                background: "rgba(255,255,255,0.06)",
                border: "1px solid rgba(255,255,255,0.08)",
              }}
              aria-label="Chat history"
            >
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none">
                <path d="M3 6H21M3 12H21M3 18H15" stroke="rgba(255,255,255,0.7)" strokeWidth="2" strokeLinecap="round" />
              </svg>
            </button>
            <div className="flex items-center gap-2">
              <div
                className="w-7 h-7 rounded-lg flex items-center justify-center text-sm font-bold"
                style={{
                  background: "linear-gradient(135deg, #3B82F6, #8B5CF6)",
                  boxShadow: "0 0 12px rgba(99,102,241,0.5)",
                }}
              >
                ⚡
              </div>
              <div>
                <span
                  className="text-white font-black text-sm tracking-tight block"
                  style={{ textShadow: "0 0 20px rgba(99,102,241,0.4)" }}
                >
                  CryptoMind AI
                </span>
                <span
                  className="text-xs font-semibold tracking-widest uppercase"
                  style={{
                    letterSpacing: "0.18em",
                    background: "linear-gradient(90deg, rgba(99,102,241,0.8), rgba(165,180,252,0.9), rgba(139,92,246,0.8))",
                    WebkitBackgroundClip: "text",
                    WebkitTextFillColor: "transparent",
                    filter: "drop-shadow(0 0 6px rgba(139,92,246,0.4))",
                  }}
                >
                  ✦ by Akash ✦
                </span>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <ShareButton
              text="Just discovered CryptoMind AI — the ultimate AI crypto analyst! Ask it anything about markets, DeFi, NFTs and more"
              className="h-8 px-3 text-xs text-white rounded-xl border-0 font-semibold bg-gradient-to-br from-blue-500 via-indigo-500 to-violet-500 shadow-[0_2px_12px_rgba(99,102,241,0.35)]"
            >
              Share
            </ShareButton>
            <button
              onClick={startNewChat}
              className="w-9 h-9 rounded-xl flex items-center justify-center transition-all duration-200 active:scale-90"
              style={{
                background: "rgba(255,255,255,0.06)",
                border: "1px solid rgba(255,255,255,0.08)",
              }}
              aria-label="New chat"
            >
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none">
                <path d="M12 5V19M5 12H19" stroke="rgba(255,255,255,0.7)" strokeWidth="2" strokeLinecap="round" />
              </svg>
            </button>
          </div>
        </div>

        {/* Market ticker */}
        <MarketTicker />
      </header>

      {/* History sidebar overlay */}
      {showHistory && (
        <div className="absolute inset-0 z-50 bg-[#050511]/97 backdrop-blur-md flex flex-col">
          {/* Header */}
          <div className="flex items-center justify-between px-4 py-3 border-b border-white/5">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-blue-500 to-violet-600 flex items-center justify-center text-xs">
                🕘
              </div>
              <h2 className="text-white font-bold text-sm">History</h2>
              {sessions.length > 0 && (
                <span className="text-xs text-white/30 bg-white/5 px-2 py-0.5 rounded-full">
                  {sessions.length}
                </span>
              )}
            </div>
            <button
              onClick={() => setShowHistory(false)}
              className="w-8 h-8 rounded-xl bg-white/5 flex items-center justify-center hover:bg-white/10 transition-colors"
            >
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none">
                <path d="M18 6L6 18M6 6L18 18" stroke="white" strokeWidth="2.5" strokeLinecap="round" />
              </svg>
            </button>
          </div>

          {/* Session list */}
          <div className="flex-1 overflow-y-auto p-3 space-y-2">
            {sessions.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-16 gap-3">
                <div className="w-14 h-14 rounded-2xl bg-white/5 flex items-center justify-center text-2xl">
                  💬
                </div>
                <p className="text-white/40 text-sm">No previous chats yet</p>
                <p className="text-white/20 text-xs text-center px-8">
                  Start a conversation and it will appear here
                </p>
              </div>
            ) : (
              sessions.map((s) => {
                const isActive = s.id === session.id;
                const lastMsg = s.messages[s.messages.length - 1];
                const lastUserMsg = [...s.messages].reverse().find((m) => m.role === "user");
                const preview = lastUserMsg?.content ?? lastMsg?.content ?? "";
                const truncatedPreview = preview.length > 55 ? preview.slice(0, 55) + "…" : preview;
                const timeAgo = (() => {
                  const diff = Date.now() - s.updatedAt.getTime();
                  const mins = Math.floor(diff / 60000);
                  const hrs = Math.floor(diff / 3600000);
                  const days = Math.floor(diff / 86400000);
                  if (mins < 1) return "just now";
                  if (mins < 60) return `${mins}m ago`;
                  if (hrs < 24) return `${hrs}h ago`;
                  return `${days}d ago`;
                })();

                return (
                  <button
                    key={s.id}
                    onClick={() => loadSession(s)}
                    className={`w-full text-left p-3 rounded-2xl transition-all border ${
                      isActive
                        ? "bg-blue-500/15 border-blue-500/40 shadow-lg shadow-blue-500/10"
                        : "bg-white/4 border-white/5 hover:bg-white/8 hover:border-white/10"
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2 mb-1.5">
                      <p className="text-white text-sm font-semibold truncate leading-tight flex-1">
                        {s.title}
                      </p>
                      {isActive && (
                        <span className="shrink-0 w-1.5 h-1.5 rounded-full bg-blue-400 mt-1.5" />
                      )}
                    </div>
                    {truncatedPreview && (
                      <p className="text-white/40 text-xs leading-relaxed line-clamp-2 mb-2">
                        {truncatedPreview}
                      </p>
                    )}
                    <div className="flex items-center gap-2">
                      <span className="text-white/25 text-xs">{timeAgo}</span>
                      <span className="text-white/15 text-xs">·</span>
                      <span className="text-white/25 text-xs">
                        {s.messages.length} msg{s.messages.length !== 1 ? "s" : ""}
                      </span>
                    </div>
                  </button>
                );
              })
            )}
          </div>

          {/* Footer actions */}
          <div className="p-3 border-t border-white/5 flex gap-2">
            <button
              onClick={startNewChat}
              className="flex-1 py-3 rounded-xl bg-gradient-to-r from-blue-600 to-violet-600 text-white font-semibold text-sm flex items-center justify-center gap-1.5 hover:opacity-90 transition-opacity"
            >
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none">
                <path d="M12 5V19M5 12H19" stroke="white" strokeWidth="2.5" strokeLinecap="round" />
              </svg>
              New Chat
            </button>
            {sessions.length > 0 && (
              <button
                onClick={() => {
                  setSessions([]);
                  startNewChat();
                }}
                className="px-4 py-3 rounded-xl bg-red-500/10 border border-red-500/20 text-red-400 font-semibold text-sm hover:bg-red-500/20 transition-colors flex items-center gap-1.5"
              >
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none">
                  <path d="M3 6H21M8 6V4H16V6M19 6L18 20H6L5 6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
                Clear all
              </button>
            )}
          </div>
        </div>
      )}

      {/* Messages area */}
      <main
        ref={messagesContainerRef}
        className="flex-1 overflow-y-auto px-4 py-4"
      >
        {!hasMessages ? (
          <SuggestedPrompts onSelect={sendMessage} />
        ) : (
          <div>
            {session.messages.map((msg) => (
              <MessageBubble key={msg.id} message={msg} />
            ))}
            <div ref={messagesEndRef} />
          </div>
        )}
      </main>

      {/* Input area */}
      <footer
        className="shrink-0 px-4 pb-4 pt-2"
        style={{ borderTop: "1px solid rgba(255,255,255,0.05)" }}
      >
        <ChatInput
          onSend={sendMessage}
          isLoading={isLoading}
          placeholder="Ask anything... (English, বাংলা, Español, हिन्दी)"
        />
        <p className="text-center mt-2 text-xs" style={{ color: "rgba(255,255,255,0.18)" }}>
          Real-time data &middot; Not financial advice &middot; Replies in your language
        </p>
      </footer>
    </div>
  );
}
