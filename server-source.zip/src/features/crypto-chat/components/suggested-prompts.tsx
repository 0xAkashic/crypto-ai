"use client";

import { useEffect, useState } from "react";
import { SUGGESTED_PROMPTS } from "@/features/crypto-chat/types";

interface SuggestedPromptsProps {
  onSelect: (prompt: string) => void;
}

// Deterministic configs — no Math.random(), no Date.now()
const ORBS = [
  { size: 220, top: "8%",  left: "-10%", color: "59,130,246",  dur: 8,  delay: 0   },
  { size: 180, top: "55%", left: "70%",  color: "139,92,246",  dur: 10, delay: 1.5 },
  { size: 140, top: "75%", left: "-5%",  color: "99,102,241",  dur: 7,  delay: 3   },
  { size: 100, top: "20%", left: "80%",  color: "59,130,246",  dur: 9,  delay: 2   },
  { size: 80,  top: "45%", left: "40%",  color: "168,85,247",  dur: 11, delay: 4   },
];

const PARTICLES = Array.from({ length: 22 }, (_, i) => ({
  id: i,
  size: i % 3 === 0 ? 3 : i % 3 === 1 ? 2 : 1.5,
  top:  `${(i * 17 + 5) % 90}%`,
  left: `${(i * 23 + 8) % 92}%`,
  dur:   3 + (i % 5),
  delay: (i * 0.4) % 4,
  color: i % 2 === 0 ? "59,130,246" : "139,92,246",
}));

const PROMPT_ICONS = ["₿", "🐍", "🌊", "🌍", "💻", "⚡", "📈", "🔧"];

function AIBrainIcon({ pulsing }: { pulsing: boolean }) {
  return (
    <svg width="52" height="52" viewBox="0 0 52 52" fill="none"
      className={pulsing ? "animate-brain-pulse" : "animate-brain-idle"}
    >
      <circle cx="26" cy="26" r="24"
        stroke="rgba(59,130,246,0.25)" strokeWidth="1"
        className="animate-spin-slow"
        strokeDasharray="4 6"
      />
      <circle cx="26" cy="26" r="18" stroke="rgba(139,92,246,0.35)" strokeWidth="1" strokeDasharray="3 4" />
      <circle cx="26" cy="26" r="12" fill="url(#brainGrad)" />
      <path d="M28 14L21 26H27L24 38L33 24H27L28 14Z" fill="white" fillOpacity="0.95" />
      <defs>
        <radialGradient id="brainGrad" cx="40%" cy="35%" r="70%">
          <stop offset="0%"   stopColor="#6366f1" />
          <stop offset="50%"  stopColor="#3B82F6" />
          <stop offset="100%" stopColor="#7c3aed" />
        </radialGradient>
      </defs>
    </svg>
  );
}

export function SuggestedPrompts({ onSelect }: SuggestedPromptsProps) {
  const [pulsing, setPulsing] = useState(false);

  useEffect(() => {
    const interval = setInterval(() => {
      setPulsing(true);
      setTimeout(() => setPulsing(false), 600);
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="relative min-h-full flex flex-col overflow-hidden py-2" suppressHydrationWarning>

      {/* Background orbs — rendered always, animated via CSS vars */}
      {ORBS.map((orb, i) => (
        <div
          key={i}
          suppressHydrationWarning
          className="absolute rounded-full pointer-events-none animate-orb-float"
          style={{
            width: orb.size,
            height: orb.size,
            top: orb.top,
            left: orb.left,
            background: `radial-gradient(circle, rgba(${orb.color},0.18) 0%, rgba(${orb.color},0.04) 60%, transparent 80%)`,
            filter: `blur(${Math.round(orb.size * 0.18)}px)`,
            "--dur": `${orb.dur}s`,
            "--delay": `${orb.delay}s`,
          } as React.CSSProperties}
        />
      ))}

      {/* Floating particles */}
      {PARTICLES.map((p) => (
        <div
          key={p.id}
          suppressHydrationWarning
          className="absolute rounded-full pointer-events-none animate-particle"
          style={{
            width: p.size,
            height: p.size,
            top: p.top,
            left: p.left,
            background: `rgba(${p.color}, 0.7)`,
            boxShadow: `0 0 ${p.size * 2}px rgba(${p.color}, 0.5)`,
            "--dur": `${p.dur}s`,
            "--delay": `${p.delay}s`,
          } as React.CSSProperties}
        />
      ))}

      {/* Hero section */}
      <div className="relative text-center px-4 pt-6 pb-4 animate-fade-up" style={{ "--delay": "0s" } as React.CSSProperties}>

        {/* Brain + ping rings */}
        <div className="relative inline-flex items-center justify-center mb-3">
          <div
            className="absolute rounded-full border border-blue-500/30 animate-ring-ping"
            style={{ width: 80, height: 80, "--delay": "0s" } as React.CSSProperties}
          />
          <div
            className="absolute rounded-full border border-violet-500/20 animate-ring-ping"
            style={{ width: 80, height: 80, "--delay": "0.8s" } as React.CSSProperties}
          />
          <AIBrainIcon pulsing={pulsing} />
        </div>

        {/* Title */}
        <h2
          className="text-white font-black text-2xl tracking-tight mb-0.5 animate-fade-up"
          style={{
            textShadow: "0 0 30px rgba(99,102,241,0.5)",
            "--delay": "0.1s",
          } as React.CSSProperties}
        >
          CryptoMind AI
        </h2>
        <p
          className="text-xs mb-1 animate-fade-up font-semibold tracking-widest uppercase"
          style={{
            letterSpacing: "0.22em",
            background: "linear-gradient(90deg, rgba(99,102,241,0.7), rgba(165,180,252,0.8), rgba(139,92,246,0.7))",
            WebkitBackgroundClip: "text",
            WebkitTextFillColor: "transparent",
            textShadow: "none",
            filter: "drop-shadow(0 0 8px rgba(139,92,246,0.5))",
            "--delay": "0.15s",
          } as React.CSSProperties}
        >
          ✦ by Akash ✦
        </p>

        {/* Shimmer badge */}
        <div
          className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full mb-2 animate-shimmer"
          style={{
            background: "linear-gradient(90deg, rgba(59,130,246,0.15), rgba(139,92,246,0.2), rgba(59,130,246,0.15))",
            backgroundSize: "200% auto",
            border: "1px solid rgba(99,102,241,0.3)",
          }}
        >
          <span
            className="w-1.5 h-1.5 rounded-full bg-blue-400 inline-block"
            style={{ boxShadow: "0 0 6px rgba(59,130,246,0.9)" }}
          />
          <span className="text-blue-200/80 text-xs font-medium tracking-wide">
            Crypto · Coding · Science · Anything
          </span>
        </div>

        <p
          className="text-white/40 text-xs leading-relaxed px-6 mt-1 animate-fade-up"
          style={{ "--delay": "0.3s" } as React.CSSProperties}
        >
          Ask anything &mdash; crypto, coding, science, math, or general knowledge. I reply in your language.
        </p>
      </div>

      {/* Prompt grid */}
      <div
        className="grid grid-cols-2 gap-2 px-3 pb-2 animate-fade-up"
        style={{ "--delay": "0.4s" } as React.CSSProperties}
      >
        {SUGGESTED_PROMPTS.map((prompt, i) => (
          <button
            key={prompt}
            onClick={() => onSelect(prompt)}
            className="relative text-left p-3 rounded-2xl overflow-hidden group active:scale-95 transition-transform duration-100"
            style={{
              background: "rgba(255,255,255,0.04)",
              border: "1px solid rgba(255,255,255,0.07)",
            }}
          >
            {/* Hover glow */}
            <div
              className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300 rounded-2xl"
              style={{ background: "linear-gradient(135deg, rgba(59,130,246,0.12), rgba(139,92,246,0.08))" }}
            />
            <div
              className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300 rounded-2xl"
              style={{ border: "1px solid rgba(99,102,241,0.35)" }}
            />
            <div className="relative flex flex-col gap-1.5">
              <span className="text-base leading-none">{PROMPT_ICONS[i]}</span>
              <p className="text-white/65 text-xs leading-relaxed group-hover:text-white/90 transition-colors duration-200">
                {prompt}
              </p>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}
