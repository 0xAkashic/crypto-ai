"use client";

import { useState, useRef, KeyboardEvent } from "react";

interface ChatInputProps {
  onSend: (message: string) => void;
  isLoading: boolean;
  placeholder?: string;
}

export function ChatInput({ onSend, isLoading, placeholder }: ChatInputProps) {
  const [value, setValue] = useState("");
  const [focused, setFocused] = useState(false);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  function handleSend() {
    const trimmed = value.trim();
    if (!trimmed || isLoading) return;
    onSend(trimmed);
    setValue("");
    if (textareaRef.current) {
      textareaRef.current.style.height = "auto";
    }
  }

  function handleKeyDown(e: KeyboardEvent<HTMLTextAreaElement>) {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  }

  function handleInput() {
    const el = textareaRef.current;
    if (!el) return;
    el.style.height = "auto";
    el.style.height = `${Math.min(el.scrollHeight, 120)}px`;
  }

  const hasText = value.trim().length > 0;

  return (
    <div
      className="flex items-end gap-2.5 p-3 rounded-2xl transition-all duration-300"
      style={{
        background: "rgba(255,255,255,0.05)",
        border: focused
          ? "1px solid rgba(99,102,241,0.6)"
          : "1px solid rgba(255,255,255,0.08)",
        backdropFilter: "blur(16px)",
        boxShadow: focused
          ? "0 0 0 3px rgba(99,102,241,0.12), 0 4px 20px rgba(0,0,0,0.3)"
          : "0 2px 12px rgba(0,0,0,0.2)",
      }}
    >
      <textarea
        ref={textareaRef}
        value={value}
        onChange={(e) => setValue(e.target.value)}
        onKeyDown={handleKeyDown}
        onInput={handleInput}
        onFocus={() => setFocused(true)}
        onBlur={() => setFocused(false)}
        placeholder={placeholder ?? "Ask anything about crypto..."}
        disabled={isLoading}
        rows={1}
        className="flex-1 bg-transparent text-white text-sm placeholder-white/25 outline-none resize-none leading-relaxed min-h-[24px] max-h-[120px] disabled:opacity-50"
      />
      <button
        onClick={handleSend}
        disabled={!hasText || isLoading}
        className="shrink-0 w-9 h-9 rounded-xl flex items-center justify-center transition-all duration-200 active:scale-90"
        style={{
          background: hasText && !isLoading
            ? "linear-gradient(135deg, #3B82F6 0%, #6366f1 50%, #8B5CF6 100%)"
            : "rgba(255,255,255,0.08)",
          boxShadow: hasText && !isLoading
            ? "0 4px 16px rgba(99,102,241,0.4), 0 1px 0 rgba(255,255,255,0.2) inset"
            : "none",
          opacity: !hasText || isLoading ? 0.4 : 1,
        }}
        aria-label="Send message"
      >
        {isLoading ? (
          <div
            className="w-4 h-4 rounded-full border-2"
            style={{
              borderColor: "rgba(255,255,255,0.2)",
              borderTopColor: "white",
              animation: "spin 0.7s linear infinite",
            }}
          />
        ) : (
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none">
            <path
              d="M22 2L11 13"
              stroke="white"
              strokeWidth="2.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
            <path
              d="M22 2L15 22L11 13L2 9L22 2Z"
              stroke="white"
              strokeWidth="2.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        )}
      </button>
    </div>
  );
}
