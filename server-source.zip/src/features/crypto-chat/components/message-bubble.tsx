"use client";

import { ChatMessage } from "@/features/crypto-chat/types";
import { TokenCard } from "@/features/crypto-chat/components/token-card";

interface MessageBubbleProps {
  message: ChatMessage;
}

function parseMarkdown(text: string): string {
  return text
    .replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>")
    .replace(/\*(.+?)\*/g, "<em>$1</em>")
    .replace(/`(.+?)`/g, '<code class="bg-blue-500/20 text-blue-300 px-1.5 py-0.5 rounded-md text-xs font-mono border border-blue-500/20">$1</code>')
    .replace(/^### (.+)$/gm, '<p class="font-bold text-blue-300 text-sm mt-3 mb-1">$1</p>')
    .replace(/^## (.+)$/gm, '<p class="font-bold text-white text-base mt-4 mb-1.5">$1</p>')
    .replace(/^# (.+)$/gm, '<p class="font-bold text-white text-lg mt-4 mb-2">$1</p>')
    .replace(/^- (.+)$/gm, '<div class="flex gap-2 my-1"><span class="text-blue-400 shrink-0 mt-0.5">▸</span><span>$1</span></div>')
    .replace(/\n\n/g, '<div class="h-2.5"></div>')
    .replace(/\n/g, "<br/>");
}

function ThinkingDots() {
  return (
    <div className="flex items-center gap-1.5 py-1 px-1">
      <div
        className="w-2 h-2 rounded-full bg-blue-400"
        style={{ animation: "thinking-bounce 1.2s ease-in-out 0ms infinite" }}
      />
      <div
        className="w-2 h-2 rounded-full bg-violet-400"
        style={{ animation: "thinking-bounce 1.2s ease-in-out 200ms infinite" }}
      />
      <div
        className="w-2 h-2 rounded-full bg-blue-400"
        style={{ animation: "thinking-bounce 1.2s ease-in-out 400ms infinite" }}
      />
    </div>
  );
}

export function MessageBubble({ message }: MessageBubbleProps) {
  const isUser = message.role === "user";

  if (isUser) {
    return (
      <div className="flex justify-end mb-5">
        <div
          className="max-w-[82%] px-4 py-3 rounded-2xl rounded-tr-sm text-white text-sm leading-relaxed shadow-xl"
          style={{
            background: "linear-gradient(135deg, #3B82F6 0%, #6366f1 50%, #8B5CF6 100%)",
            boxShadow: "0 4px 24px rgba(99,102,241,0.35), 0 1px 0 rgba(255,255,255,0.15) inset",
          }}
        >
          {message.content}
        </div>
      </div>
    );
  }

  return (
    <div className="flex gap-3 mb-5">
      {/* AI avatar */}
      <div
        className="shrink-0 w-8 h-8 rounded-xl flex items-center justify-center text-sm font-bold shadow-lg"
        style={{
          background: "linear-gradient(135deg, #3B82F6, #8B5CF6)",
          boxShadow: "0 0 16px rgba(99,102,241,0.5)",
        }}
      >
        <span>⚡</span>
      </div>

      {/* Message content */}
      <div className="flex-1 min-w-0">
        <div
          className="px-4 py-3 rounded-2xl rounded-tl-sm"
          style={{
            background: "rgba(255,255,255,0.05)",
            border: "1px solid rgba(255,255,255,0.09)",
            backdropFilter: "blur(12px)",
            boxShadow: "0 2px 16px rgba(0,0,0,0.3), inset 0 1px 0 rgba(255,255,255,0.06)",
          }}
        >
          {message.isStreaming && !message.content ? (
            <ThinkingDots />
          ) : (
            <div
              className="text-sm text-white/90 leading-relaxed"
              dangerouslySetInnerHTML={{ __html: parseMarkdown(message.content) }}
            />
          )}
          {message.isStreaming && message.content && (
            <span
              className="inline-block w-0.5 h-[14px] bg-blue-400 ml-0.5 align-middle"
              style={{ animation: "cursor-blink 1s step-end infinite" }}
            />
          )}
        </div>

        {/* Token card if present */}
        {message.tokenData && !message.isStreaming && (
          <TokenCard token={message.tokenData} />
        )}

        <p className="text-white/25 text-xs mt-1.5 ml-1">
          {message.timestamp.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
        </p>
      </div>
    </div>
  );
}
