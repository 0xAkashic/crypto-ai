"use client";

import { AIMode, AI_MODES } from "@/features/crypto-chat/types";

interface ModeSelectorProps {
  mode: AIMode;
  onModeChange: (mode: AIMode) => void;
}

// Glow color per mode for the active indicator
const MODE_GLOW: Record<string, string> = {
  trader: "rgba(59,130,246,0.4)",
  analyst: "rgba(99,102,241,0.4)",
  defi: "rgba(139,92,246,0.4)",
  nft: "rgba(168,85,247,0.4)",
  educator: "rgba(59,130,246,0.35)",
};

export function ModeSelector({ mode, onModeChange }: ModeSelectorProps) {
  return (
    <div className="flex gap-1.5 overflow-x-auto pb-0.5 scrollbar-hide">
      {(Object.entries(AI_MODES) as [AIMode, (typeof AI_MODES)[AIMode]][]).map(
        ([key, config]) => {
          const isActive = mode === key;
          return (
            <button
              key={key}
              onClick={() => onModeChange(key)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold shrink-0 transition-all duration-200 active:scale-95"
              style={
                isActive
                  ? {
                      background: "linear-gradient(135deg, rgba(59,130,246,0.3), rgba(139,92,246,0.3))",
                      border: "1px solid rgba(99,102,241,0.5)",
                      color: "white",
                      boxShadow: `0 0 12px ${MODE_GLOW[key] ?? "rgba(99,102,241,0.3)"}, 0 1px 0 rgba(255,255,255,0.1) inset`,
                    }
                  : {
                      background: "rgba(255,255,255,0.04)",
                      border: "1px solid rgba(255,255,255,0.07)",
                      color: "rgba(255,255,255,0.45)",
                    }
              }
            >
              <span className="text-sm leading-none">{config.icon}</span>
              <span>{config.label}</span>
            </button>
          );
        }
      )}
    </div>
  );
}
