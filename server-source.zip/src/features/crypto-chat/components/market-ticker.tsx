"use client";

import { useState, useEffect } from "react";
import { useSimplePrice } from "@/neynar-web-sdk/coingecko";

const TICKER_COINS = ["bitcoin", "ethereum", "solana", "pepe", "dogecoin"];
const SYMBOLS: Record<string, string> = {
  bitcoin: "BTC",
  ethereum: "ETH",
  solana: "SOL",
  pepe: "PEPE",
  dogecoin: "DOGE",
};
const COIN_EMOJI: Record<string, string> = {
  bitcoin: "₿",
  ethereum: "Ξ",
  solana: "◎",
  pepe: "🐸",
  dogecoin: "Ð",
};

function TickerSkeleton() {
  return (
    <div className="flex gap-2 overflow-x-auto pb-0.5 scrollbar-hide">
      {TICKER_COINS.map((id) => (
        <div
          key={id}
          className="shrink-0 flex items-center gap-2 px-3 py-1.5 rounded-full"
          style={{
            background: "rgba(255,255,255,0.05)",
            border: "1px solid rgba(255,255,255,0.06)",
          }}
        >
          <span className="text-white/60 text-xs font-bold">{SYMBOLS[id]}</span>
          <span
            className="h-3 w-12 rounded-full"
            style={{ background: "rgba(255,255,255,0.07)", display: "inline-block" }}
          />
        </div>
      ))}
    </div>
  );
}

function TickerContent() {
  const { data: prices } = useSimplePrice(
    TICKER_COINS,
    ["usd"],
    { include24hrChange: true },
    {
      refetchInterval: 60000,
      staleTime: 55000,
      refetchOnWindowFocus: false,
    }
  );

  const items = TICKER_COINS.map((id) => ({
    id,
    symbol: SYMBOLS[id],
    emoji: COIN_EMOJI[id],
    price: prices?.[id]?.usd ?? null,
    change: prices?.[id]?.usd_24h_change ?? null,
  }));

  return (
    <div className="flex gap-2 overflow-x-auto pb-0.5 scrollbar-hide">
      {items.map((item) => {
        const isPositive = (item.change ?? 0) >= 0;
        const glowColor = isPositive ? "rgba(52,211,153,0.15)" : "rgba(248,113,113,0.15)";
        const borderColor = isPositive ? "rgba(52,211,153,0.2)" : "rgba(248,113,113,0.2)";

        return (
          <div
            key={item.id}
            className="shrink-0 flex items-center gap-1.5 px-3 py-1.5 rounded-full transition-all duration-300"
            style={{
              background: item.price !== null
                ? `rgba(255,255,255,0.05)`
                : "rgba(255,255,255,0.04)",
              border: item.price !== null
                ? `1px solid ${borderColor}`
                : "1px solid rgba(255,255,255,0.06)",
              boxShadow: item.price !== null ? `0 0 8px ${glowColor}` : "none",
            }}
          >
            <span className="text-xs leading-none">{item.emoji}</span>
            <span className="text-white/80 text-xs font-bold tracking-wide">{item.symbol}</span>
            {item.price !== null ? (
              <>
                <span className="text-white text-xs font-semibold">
                  {item.price >= 1000
                    ? `$${item.price.toLocaleString("en-US", { maximumFractionDigits: 0 })}`
                    : item.price >= 1
                    ? `$${item.price.toFixed(2)}`
                    : `$${item.price.toFixed(5)}`}
                </span>
                {item.change !== null && (
                  <span
                    className="text-xs font-bold"
                    style={{ color: isPositive ? "#34d399" : "#f87171" }}
                  >
                    {isPositive ? "+" : ""}{item.change.toFixed(1)}%
                  </span>
                )}
              </>
            ) : (
              <span className="text-white/20 text-xs">—</span>
            )}
          </div>
        );
      })}
    </div>
  );
}

export function MarketTicker() {
  const [mounted, setMounted] = useState(false);
  useEffect(() => {
    const t = setTimeout(() => setMounted(true), 200);
    return () => clearTimeout(t);
  }, []);

  return mounted ? <TickerContent /> : <TickerSkeleton />;
}
