"use client";

import { TokenData } from "@/features/crypto-chat/types";

interface TokenCardProps {
  token: TokenData;
}

function formatPrice(price: number): string {
  if (price >= 1000) return `$${price.toLocaleString("en-US", { maximumFractionDigits: 2 })}`;
  if (price >= 1) return `$${price.toFixed(4)}`;
  if (price >= 0.0001) return `$${price.toFixed(6)}`;
  return `$${price.toExponential(4)}`;
}

function formatMarketCap(value: number): string {
  if (value >= 1e12) return `$${(value / 1e12).toFixed(2)}T`;
  if (value >= 1e9) return `$${(value / 1e9).toFixed(2)}B`;
  if (value >= 1e6) return `$${(value / 1e6).toFixed(2)}M`;
  return `$${value.toLocaleString()}`;
}

export function TokenCard({ token }: TokenCardProps) {
  const isPositive = token.price_change_percentage_24h >= 0;
  const changeColor = isPositive ? "#34d399" : "#f87171";
  const changeBg = isPositive ? "rgba(52,211,153,0.1)" : "rgba(248,113,113,0.1)";
  const changeBorder = isPositive ? "rgba(52,211,153,0.25)" : "rgba(248,113,113,0.25)";

  return (
    <div
      className="mt-3 rounded-2xl p-4 overflow-hidden relative"
      style={{
        background: "linear-gradient(135deg, rgba(15,23,42,0.95) 0%, rgba(10,15,30,0.98) 100%)",
        border: "1px solid rgba(99,102,241,0.25)",
        boxShadow: "0 8px 32px rgba(0,0,0,0.4), 0 0 0 1px rgba(255,255,255,0.04) inset, 0 1px 0 rgba(255,255,255,0.08) inset",
        backdropFilter: "blur(20px)",
      }}
    >
      {/* Subtle top glow */}
      <div
        className="absolute top-0 left-0 right-0 h-px"
        style={{ background: "linear-gradient(90deg, transparent, rgba(99,102,241,0.5), transparent)" }}
      />

      {/* Header row */}
      <div className="flex items-center gap-3 mb-4">
        <div className="relative">
          {token.image && (
            // eslint-disable-next-line @next/next/no-img-element
            <img
              src={token.image}
              alt={token.name}
              className="w-11 h-11 rounded-full"
              style={{
                boxShadow: `0 0 0 2px rgba(99,102,241,0.3), 0 0 16px rgba(99,102,241,0.2)`,
              }}
            />
          )}
          <div
            className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 rounded-full border-2 border-[#0a0f1e] flex items-center justify-center"
            style={{ background: "#34d399" }}
          />
        </div>
        <div className="flex-1 min-w-0">
          <p className="font-bold text-white text-base leading-tight">{token.name}</p>
          <p
            className="text-xs uppercase tracking-widest font-semibold"
            style={{ color: "rgba(139,92,246,0.8)" }}
          >
            {token.symbol}
          </p>
        </div>
        <div className="text-right">
          <p
            className="font-black text-white text-xl leading-tight"
            style={{ textShadow: "0 0 20px rgba(255,255,255,0.2)" }}
          >
            {formatPrice(token.current_price)}
          </p>
          <div
            className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full mt-1"
            style={{
              background: changeBg,
              border: `1px solid ${changeBorder}`,
            }}
          >
            <span className="text-xs font-bold" style={{ color: changeColor }}>
              {isPositive ? "▲" : "▼"} {Math.abs(token.price_change_percentage_24h).toFixed(2)}%
            </span>
          </div>
        </div>
      </div>

      {/* Divider */}
      <div
        className="h-px mb-4"
        style={{ background: "linear-gradient(90deg, transparent, rgba(255,255,255,0.06), transparent)" }}
      />

      {/* Stats grid */}
      <div className="grid grid-cols-2 gap-2.5 mb-3">
        <div
          className="rounded-xl p-3"
          style={{
            background: "rgba(255,255,255,0.04)",
            border: "1px solid rgba(255,255,255,0.06)",
          }}
        >
          <p className="text-xs mb-1 font-medium" style={{ color: "rgba(139,92,246,0.7)" }}>
            Market Cap
          </p>
          <p className="text-white text-sm font-bold">{formatMarketCap(token.market_cap)}</p>
        </div>
        <div
          className="rounded-xl p-3"
          style={{
            background: "rgba(255,255,255,0.04)",
            border: "1px solid rgba(255,255,255,0.06)",
          }}
        >
          <p className="text-xs mb-1 font-medium" style={{ color: "rgba(59,130,246,0.7)" }}>
            24h Volume
          </p>
          <p className="text-white text-sm font-bold">{formatMarketCap(token.total_volume)}</p>
        </div>
      </div>

      {/* Live badge */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-1.5">
          <span className="relative flex h-1.5 w-1.5">
            <span
              className="absolute inline-flex h-full w-full rounded-full opacity-75"
              style={{ background: "#34d399", animation: "ping 1.5s cubic-bezier(0,0,0.2,1) infinite" }}
            />
            <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-emerald-400" />
          </span>
          <span className="text-xs font-medium" style={{ color: "rgba(52,211,153,0.7)" }}>
            Live · CoinGecko
          </span>
        </div>
        <div
          className="text-xs px-2 py-0.5 rounded-full font-medium"
          style={{
            background: "rgba(99,102,241,0.12)",
            border: "1px solid rgba(99,102,241,0.2)",
            color: "rgba(165,180,252,0.8)",
          }}
        >
          Real-time data
        </div>
      </div>
    </div>
  );
}
