"use client";

import { useState, useEffect, useCallback, useRef } from "react";

export type AlertCondition = "above" | "below";
export type AlertStatus = "active" | "triggered";

export interface PriceAlert {
  id: string;
  coinId: string;
  coinName: string;
  symbol: string;
  targetPrice: number;
  condition: AlertCondition;
  status: AlertStatus;
  createdAt: number;
  triggeredAt?: number;
}

const STORAGE_KEY = "cryptomind_alerts";
const POLL_INTERVAL = 60_000; // 1 minute

function loadAlerts(): PriceAlert[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

function saveAlerts(alerts: PriceAlert[]) {
  if (typeof window === "undefined") return;
  localStorage.setItem(STORAGE_KEY, JSON.stringify(alerts));
}

export interface TriggeredAlert {
  alert: PriceAlert;
  currentPrice: number;
}

export function useAlerts() {
  const [alerts, setAlerts] = useState<PriceAlert[]>([]);
  const [triggered, setTriggered] = useState<TriggeredAlert[]>([]);
  const [isChecking, setIsChecking] = useState(false);
  const alertsRef = useRef<PriceAlert[]>([]);

  // Load on mount
  useEffect(() => {
    const loaded = loadAlerts();
    setAlerts(loaded);
    alertsRef.current = loaded;
  }, []);

  const updateAlerts = useCallback((next: PriceAlert[]) => {
    setAlerts(next);
    alertsRef.current = next;
    saveAlerts(next);
  }, []);

  const addAlert = useCallback((alert: Omit<PriceAlert, "id" | "createdAt" | "status">) => {
    const newAlert: PriceAlert = {
      ...alert,
      id: `${Date.now()}-${Math.random().toString(36).slice(2)}`,
      createdAt: Date.now(),
      status: "active",
    };
    const next = [newAlert, ...alertsRef.current];
    updateAlerts(next);
  }, [updateAlerts]);

  const removeAlert = useCallback((id: string) => {
    const next = alertsRef.current.filter((a) => a.id !== id);
    updateAlerts(next);
  }, [updateAlerts]);

  const dismissTriggered = useCallback((id: string) => {
    setTriggered((prev) => prev.filter((t) => t.alert.id !== id));
  }, []);

  const checkPrices = useCallback(async () => {
    const active = alertsRef.current.filter((a) => a.status === "active");
    if (!active.length) return;

    setIsChecking(true);
    try {
      const ids = [...new Set(active.map((a) => a.coinId))].join(",");
      const res = await fetch(
        `/api/coingecko/coins/markets?vs_currency=usd&ids=${ids}&per_page=50&page=1&sparkline=false`
      );
      if (!res.ok) return;
      const data: Array<{ id: string; current_price: number }> = await res.json();

      const priceMap: Record<string, number> = {};
      for (const coin of data) priceMap[coin.id] = coin.current_price;

      const newTriggered: TriggeredAlert[] = [];
      const updated = alertsRef.current.map((alert) => {
        if (alert.status !== "active") return alert;
        const price = priceMap[alert.coinId];
        if (price === undefined) return alert;

        const hit =
          (alert.condition === "above" && price >= alert.targetPrice) ||
          (alert.condition === "below" && price <= alert.targetPrice);

        if (hit) {
          newTriggered.push({ alert, currentPrice: price });
          return { ...alert, status: "triggered" as AlertStatus, triggeredAt: Date.now() };
        }
        return alert;
      });

      if (newTriggered.length) {
        updateAlerts(updated);
        setTriggered((prev) => [...newTriggered, ...prev]);
      }
    } finally {
      setIsChecking(false);
    }
  }, [updateAlerts]);

  // Poll on interval
  useEffect(() => {
    checkPrices();
    const interval = setInterval(checkPrices, POLL_INTERVAL);
    return () => clearInterval(interval);
  }, [checkPrices]);

  const activeAlerts = alerts.filter((a) => a.status === "active");
  const triggeredAlerts = alerts.filter((a) => a.status === "triggered");

  return {
    alerts,
    activeAlerts,
    triggeredAlerts,
    triggered,
    isChecking,
    addAlert,
    removeAlert,
    dismissTriggered,
    checkPrices,
  };
}
