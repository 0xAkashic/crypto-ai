"use client";

import { useState } from "react";
import type { AlertCondition } from "./use-alerts";

const POPULAR_COINS = [
  { id: "bitcoin", name: "Bitcoin", symbol: "BTC" },
  { id: "ethereum", name: "Ethereum", symbol: "ETH" },
  { id: "solana", name: "Solana", symbol: "SOL" },
  { id: "binancecoin", name: "BNB", symbol: "BNB" },
  { id: "ripple", name: "XRP", symbol: "XRP" },
  { id: "dogecoin", name: "Dogecoin", symbol: "DOGE" },
  { id: "cardano", name: "Cardano", symbol: "ADA" },
  { id: "avalanche-2", name: "Avalanche", symbol: "AVAX" },
  { id: "chainlink", name: "Chainlink", symbol: "LINK" },
  { id: "shiba-inu", name: "Shiba Inu", symbol: "SHIB" },
  { id: "pepe", name: "Pepe", symbol: "PEPE" },
  { id: "the-open-network", name: "Toncoin", symbol: "TON" },
];

interface Props {
  onAdd: (data: {
    coinId: string;
    coinName: string;
    symbol: string;
    targetPrice: number;
    condition: AlertCondition;
  }) => void;
  onClose: () => void;
}

export function AddAlertModal({ onAdd, onClose }: Props) {
  const [step, setStep] = useState<"coin" | "price">("coin");
  const [search, setSearch] = useState("");
  const [selectedCoin, setSelectedCoin] = useState<(typeof POPULAR_COINS)[0] | null>(null);
  const [targetPrice, setTargetPrice] = useState("");
  const [condition, setCondition] = useState<AlertCondition>("above");

  const filtered = POPULAR_COINS.filter(
    (c) =>
      c.name.toLowerCase().includes(search.toLowerCase()) ||
      c.symbol.toLowerCase().includes(search.toLowerCase())
  );

  const handleSubmit = () => {
    if (!selectedCoin || !targetPrice) return;
    const price = parseFloat(targetPrice.replace(/,/g, ""));
    if (isNaN(price) || price <= 0) return;
    onAdd({
      coinId: selectedCoin.id,
      coinName: selectedCoin.name,
      symbol: selectedCoin.symbol,
      targetPrice: price,
      condition,
    });
    onClose();
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-end justify-center"
      style={{ background: "rgba(0,0,0,0.7)", backdropFilter: "blur(8px)" }}
      onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}
    >
      <div
        className="w-full max-w-md rounded-t-3xl flex flex-col"
        style={{
          background: "linear-gradient(180deg, #0f0e2a 0%, #080720 100%)",
          border: "1px solid rgba(99,102,241,0.2)",
          borderBottom: "none",
          maxHeight: "80vh",
        }}
      >
        {/* Drag handle */}
        <div className="flex justify-center pt-3 pb-1">
          <div className="w-10 h-1 rounded-full" style={{ background: "rgba(255,255,255,0.15)" }} />
        </div>

        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3">
          <div>
            <h2 className="text-white font-bold text-lg">
              {step === "coin" ? "Choose Coin" : `Alert for ${selectedCoin?.symbol}`}
            </h2>
            <p className="text-xs mt-0.5" style={{ color: "rgba(255,255,255,0.4)" }}>
              {step === "coin" ? "Select which coin to watch" : "Set your target price"}
            </p>
          </div>
          <button onClick={onClose} className="w-8 h-8 rounded-full flex items-center justify-center" style={{ background: "rgba(255,255,255,0.08)", color: "rgba(255,255,255,0.5)" }}>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none">
              <path d="M18 6L6 18M6 6l12 12" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" />
            </svg>
          </button>
        </div>

        {step === "coin" ? (
          <>
            {/* Search */}
            <div className="px-5 pb-3">
              <div className="flex items-center gap-2 px-3 py-2.5 rounded-xl" style={{ background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.09)" }}>
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" style={{ color: "rgba(255,255,255,0.3)" }}>
                  <circle cx="11" cy="11" r="8" stroke="currentColor" strokeWidth="2" />
                  <path d="M21 21l-4.35-4.35" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
                </svg>
                <input
                  className="flex-1 bg-transparent text-white text-sm outline-none placeholder:text-white/30"
                  placeholder="Search coins..."
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  autoFocus
                />
              </div>
            </div>

            {/* Coin list */}
            <div className="overflow-y-auto flex-1 px-5 pb-6 flex flex-col gap-2">
              {filtered.map((coin) => (
                <button
                  key={coin.id}
                  onClick={() => { setSelectedCoin(coin); setStep("price"); }}
                  className="flex items-center gap-3 px-4 py-3 rounded-2xl text-left transition-all active:scale-98"
                  style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.07)" }}
                >
                  <div className="w-9 h-9 rounded-full flex items-center justify-center text-sm font-bold" style={{ background: "rgba(99,102,241,0.2)", color: "#a78bfa" }}>
                    {coin.symbol.slice(0, 2)}
                  </div>
                  <div>
                    <div className="text-white font-semibold text-sm">{coin.name}</div>
                    <div className="text-xs" style={{ color: "rgba(255,255,255,0.4)" }}>{coin.symbol}</div>
                  </div>
                  <svg className="ml-auto" width="16" height="16" viewBox="0 0 24 24" fill="none" style={{ color: "rgba(255,255,255,0.2)" }}>
                    <path d="M9 18l6-6-6-6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                </button>
              ))}
            </div>
          </>
        ) : (
          <div className="px-5 pb-6 flex flex-col gap-4 overflow-y-auto">
            {/* Back */}
            <button onClick={() => setStep("coin")} className="flex items-center gap-1.5 text-sm w-fit" style={{ color: "rgba(165,180,252,0.8)" }}>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none">
                <path d="M15 18l-6-6 6-6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
              Back
            </button>

            {/* Condition toggle */}
            <div>
              <label className="text-xs font-semibold mb-2 block" style={{ color: "rgba(255,255,255,0.5)" }}>ALERT WHEN PRICE IS</label>
              <div className="flex gap-2">
                {(["above", "below"] as AlertCondition[]).map((c) => (
                  <button
                    key={c}
                    onClick={() => setCondition(c)}
                    className="flex-1 py-3 rounded-xl text-sm font-bold transition-all"
                    style={
                      condition === c
                        ? {
                            background: c === "above"
                              ? "linear-gradient(135deg, rgba(74,222,128,0.2), rgba(34,197,94,0.15))"
                              : "linear-gradient(135deg, rgba(248,113,113,0.2), rgba(239,68,68,0.15))",
                            border: `1px solid ${c === "above" ? "rgba(74,222,128,0.4)" : "rgba(248,113,113,0.4)"}`,
                            color: c === "above" ? "#4ade80" : "#f87171",
                          }
                        : {
                            background: "rgba(255,255,255,0.04)",
                            border: "1px solid rgba(255,255,255,0.08)",
                            color: "rgba(255,255,255,0.4)",
                          }
                    }
                  >
                    {c === "above" ? "▲ Above" : "▼ Below"}
                  </button>
                ))}
              </div>
            </div>

            {/* Target price input */}
            <div>
              <label className="text-xs font-semibold mb-2 block" style={{ color: "rgba(255,255,255,0.5)" }}>TARGET PRICE (USD)</label>
              <div className="flex items-center gap-2 px-4 py-3.5 rounded-xl" style={{ background: "rgba(255,255,255,0.06)", border: "1px solid rgba(99,102,241,0.3)" }}>
                <span className="text-lg font-bold" style={{ color: "rgba(255,255,255,0.4)" }}>$</span>
                <input
                  type="number"
                  className="flex-1 bg-transparent text-white text-xl font-bold outline-none"
                  placeholder="0.00"
                  value={targetPrice}
                  onChange={(e) => setTargetPrice(e.target.value)}
                  autoFocus
                  min="0"
                  step="any"
                />
              </div>
            </div>

            {/* Summary */}
            {targetPrice && parseFloat(targetPrice) > 0 && (
              <div className="rounded-xl p-4 flex items-center gap-3" style={{ background: "rgba(99,102,241,0.1)", border: "1px solid rgba(99,102,241,0.2)" }}>
                <div className="text-2xl">🔔</div>
                <div className="text-sm" style={{ color: "rgba(255,255,255,0.7)" }}>
                  Alert when <span className="text-white font-bold">{selectedCoin?.symbol}</span> goes{" "}
                  <span className="font-bold" style={{ color: condition === "above" ? "#4ade80" : "#f87171" }}>
                    {condition}
                  </span>{" "}
                  <span className="text-white font-bold">${parseFloat(targetPrice).toLocaleString()}</span>
                </div>
              </div>
            )}

            {/* Submit */}
            <button
              onClick={handleSubmit}
              disabled={!targetPrice || parseFloat(targetPrice) <= 0}
              className="py-4 rounded-2xl text-white font-bold text-base transition-all active:scale-98 disabled:opacity-40"
              style={{
                background: "linear-gradient(135deg, #3B82F6, #6366f1, #8B5CF6)",
                boxShadow: "0 4px 20px rgba(99,102,241,0.4)",
              }}
            >
              Set Alert
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
