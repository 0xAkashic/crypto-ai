"use client";

import { useState } from "react";
import { useAlerts } from "./use-alerts";
import { AddAlertModal } from "./add-alert-modal";
import type { PriceAlert } from "./use-alerts";

interface Props {
  onCheckPrices: () => void;
  isChecking: boolean;
  activeAlerts: PriceAlert[];
  triggeredAlerts: PriceAlert[];
  onAdd: (data: Parameters<ReturnType<typeof useAlerts>["addAlert"]>[0]) => void;
  onRemove: (id: string) => void;
}

export function AlertsScreen({
  onCheckPrices,
  isChecking,
  activeAlerts,
  triggeredAlerts,
  onAdd,
  onRemove,
}: Props) {
  const [showModal, setShowModal] = useState(false);
  const [tab, setTab] = useState<"active" | "history">("active");

  const displayAlerts = tab === "active" ? activeAlerts : triggeredAlerts;

  return (
    <div className="h-full flex flex-col overflow-hidden">
      {/* Header */}
      <div
        className="shrink-0 px-5 pt-5 pb-4"
        style={{ borderBottom: "1px solid rgba(255,255,255,0.06)" }}
      >
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="text-white font-bold text-xl tracking-tight">Price Alerts</h1>
            <p className="text-xs mt-0.5" style={{ color: "rgba(255,255,255,0.4)" }}>
              Checks every 60 seconds
            </p>
          </div>
          <div className="flex items-center gap-2">
            {/* Refresh */}
            <button
              onClick={onCheckPrices}
              disabled={isChecking}
              className="w-9 h-9 rounded-xl flex items-center justify-center transition-all active:scale-95 disabled:opacity-50"
              style={{ background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.09)" }}
            >
              <svg
                width="16" height="16" viewBox="0 0 24 24" fill="none"
                style={{ color: "rgba(255,255,255,0.6)", animation: isChecking ? "spin 1s linear infinite" : "none" }}
              >
                <path d="M1 4v6h6M23 20v-6h-6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                <path d="M20.49 9A9 9 0 0 0 5.64 5.64L1 10m22 4l-4.64 4.36A9 9 0 0 1 3.51 15" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            </button>
            {/* Add */}
            <button
              onClick={() => setShowModal(true)}
              className="flex items-center gap-2 px-4 py-2 rounded-xl font-bold text-sm text-white transition-all active:scale-95"
              style={{
                background: "linear-gradient(135deg, #3B82F6, #8B5CF6)",
                boxShadow: "0 4px 16px rgba(99,102,241,0.35)",
              }}
            >
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none">
                <path d="M12 5v14M5 12h14" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" />
              </svg>
              Add Alert
            </button>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex gap-1 p-1 rounded-xl" style={{ background: "rgba(255,255,255,0.04)" }}>
          {(["active", "history"] as const).map((t) => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className="flex-1 py-2 rounded-lg text-sm font-semibold capitalize transition-all"
              style={
                tab === t
                  ? { background: "rgba(99,102,241,0.3)", color: "white", border: "1px solid rgba(99,102,241,0.4)" }
                  : { background: "transparent", color: "rgba(255,255,255,0.4)", border: "1px solid transparent" }
              }
            >
              {t === "active" ? `Active (${activeAlerts.length})` : `History (${triggeredAlerts.length})`}
            </button>
          ))}
        </div>
      </div>

      {/* Alert list */}
      <div className="flex-1 overflow-y-auto px-4 py-4 flex flex-col gap-3">
        {displayAlerts.length === 0 ? (
          <EmptyState tab={tab} onAdd={() => setShowModal(true)} />
        ) : (
          displayAlerts.map((alert) => (
            <AlertCard
              key={alert.id}
              alert={alert}
              onRemove={() => onRemove(alert.id)}
            />
          ))
        )}
      </div>

      {showModal && (
        <AddAlertModal onAdd={onAdd} onClose={() => setShowModal(false)} />
      )}
    </div>
  );
}

function AlertCard({ alert, onRemove }: { alert: PriceAlert; onRemove: () => void }) {
  const isTriggered = alert.status === "triggered";
  const isAbove = alert.condition === "above";

  return (
    <div
      className="rounded-2xl p-4 flex items-center gap-3"
      style={{
        background: isTriggered
          ? "rgba(255,255,255,0.03)"
          : "rgba(255,255,255,0.05)",
        border: isTriggered
          ? "1px solid rgba(255,255,255,0.06)"
          : `1px solid ${isAbove ? "rgba(74,222,128,0.2)" : "rgba(248,113,113,0.2)"}`,
      }}
    >
      {/* Coin badge */}
      <div
        className="w-11 h-11 rounded-xl flex items-center justify-center text-xs font-bold shrink-0"
        style={{
          background: isTriggered
            ? "rgba(255,255,255,0.06)"
            : isAbove
            ? "rgba(74,222,128,0.12)"
            : "rgba(248,113,113,0.12)",
          color: isTriggered ? "rgba(255,255,255,0.4)" : isAbove ? "#4ade80" : "#f87171",
        }}
      >
        {alert.symbol.slice(0, 3)}
      </div>

      {/* Info */}
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 mb-0.5">
          <span className="text-white font-bold text-sm">{alert.coinName}</span>
          <span
            className="text-xs font-bold px-1.5 py-0.5 rounded-full"
            style={{
              background: isTriggered
                ? "rgba(255,255,255,0.08)"
                : isAbove
                ? "rgba(74,222,128,0.15)"
                : "rgba(248,113,113,0.15)",
              color: isTriggered
                ? "rgba(255,255,255,0.4)"
                : isAbove
                ? "#4ade80"
                : "#f87171",
            }}
          >
            {isAbove ? "▲" : "▼"} {isTriggered ? "HIT" : alert.condition.toUpperCase()}
          </span>
        </div>
        <div className="text-sm font-semibold" style={{ color: isTriggered ? "rgba(255,255,255,0.3)" : "rgba(255,255,255,0.7)" }}>
          ${alert.targetPrice.toLocaleString("en-US", { maximumFractionDigits: 8 })}
        </div>
        <div className="text-xs mt-0.5" style={{ color: "rgba(255,255,255,0.25)" }}>
          {isTriggered && alert.triggeredAt
            ? `Triggered ${new Date(alert.triggeredAt).toLocaleDateString()}`
            : `Set ${new Date(alert.createdAt).toLocaleDateString()}`}
        </div>
      </div>

      {/* Bell / check icon */}
      <div className="flex items-center gap-2">
        <div
          className="w-8 h-8 rounded-xl flex items-center justify-center text-base"
          style={{
            background: isTriggered ? "rgba(255,255,255,0.05)" : "rgba(99,102,241,0.15)",
          }}
        >
          {isTriggered ? "✓" : "🔔"}
        </div>
        <button
          onClick={onRemove}
          className="w-8 h-8 rounded-xl flex items-center justify-center transition-all active:scale-95"
          style={{ background: "rgba(248,113,113,0.1)", color: "#f87171" }}
        >
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none">
            <path d="M3 6h18M8 6V4h8v2M19 6l-1 14H6L5 6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </button>
      </div>
    </div>
  );
}

function EmptyState({ tab, onAdd }: { tab: "active" | "history"; onAdd: () => void }) {
  return (
    <div className="flex-1 flex flex-col items-center justify-center py-16 px-6 text-center">
      <div
        className="w-16 h-16 rounded-2xl flex items-center justify-center text-3xl mb-4"
        style={{ background: "rgba(99,102,241,0.12)", border: "1px solid rgba(99,102,241,0.2)" }}
      >
        {tab === "active" ? "🔔" : "📋"}
      </div>
      <div className="text-white font-bold text-base mb-1">
        {tab === "active" ? "No active alerts" : "No alert history"}
      </div>
      <div className="text-sm mb-5" style={{ color: "rgba(255,255,255,0.35)" }}>
        {tab === "active"
          ? "Set a price target and get notified when your coin hits it"
          : "Triggered alerts will appear here"}
      </div>
      {tab === "active" && (
        <button
          onClick={onAdd}
          className="px-6 py-3 rounded-2xl text-white font-bold text-sm transition-all active:scale-95"
          style={{
            background: "linear-gradient(135deg, #3B82F6, #8B5CF6)",
            boxShadow: "0 4px 16px rgba(99,102,241,0.35)",
          }}
        >
          + Create Your First Alert
        </button>
      )}
    </div>
  );
}
