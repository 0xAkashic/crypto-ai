"use client";

import { useEffect } from "react";
import type { TriggeredAlert } from "./use-alerts";

interface Props {
  toasts: TriggeredAlert[];
  onDismiss: (id: string) => void;
}

export function AlertToast({ toasts, onDismiss }: Props) {
  // Auto-dismiss after 8 seconds
  useEffect(() => {
    if (!toasts.length) return;
    const timers = toasts.map((t) =>
      setTimeout(() => onDismiss(t.alert.id), 8000)
    );
    return () => timers.forEach(clearTimeout);
  }, [toasts, onDismiss]);

  if (!toasts.length) return null;

  return (
    <div className="fixed top-4 left-0 right-0 z-50 flex flex-col gap-2 px-4 pointer-events-none">
      {toasts.map(({ alert, currentPrice }) => (
        <div
          key={alert.id}
          className="pointer-events-auto rounded-2xl p-4 flex items-start gap-3 animate-slide-in"
          style={{
            background: "linear-gradient(135deg, rgba(15,14,42,0.98), rgba(8,7,32,0.98))",
            border: alert.condition === "above"
              ? "1px solid rgba(74,222,128,0.5)"
              : "1px solid rgba(248,113,113,0.5)",
            boxShadow: alert.condition === "above"
              ? "0 8px 32px rgba(74,222,128,0.2)"
              : "0 8px 32px rgba(248,113,113,0.2)",
            backdropFilter: "blur(20px)",
          }}
        >
          {/* Icon */}
          <div
            className="w-10 h-10 rounded-xl flex items-center justify-center text-lg shrink-0"
            style={{
              background: alert.condition === "above"
                ? "rgba(74,222,128,0.15)"
                : "rgba(248,113,113,0.15)",
            }}
          >
            {alert.condition === "above" ? "🚀" : "📉"}
          </div>

          {/* Content */}
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-0.5">
              <span className="text-white font-bold text-sm">{alert.symbol} Alert Triggered!</span>
              <span
                className="text-xs font-bold px-2 py-0.5 rounded-full"
                style={{
                  background: alert.condition === "above" ? "rgba(74,222,128,0.2)" : "rgba(248,113,113,0.2)",
                  color: alert.condition === "above" ? "#4ade80" : "#f87171",
                }}
              >
                {alert.condition === "above" ? "▲ ABOVE" : "▼ BELOW"}
              </span>
            </div>
            <div className="text-sm" style={{ color: "rgba(255,255,255,0.6)" }}>
              {alert.coinName} hit{" "}
              <span
                className="font-bold"
                style={{ color: alert.condition === "above" ? "#4ade80" : "#f87171" }}
              >
                ${currentPrice.toLocaleString("en-US", { maximumFractionDigits: 6 })}
              </span>
              {" "}(target: ${alert.targetPrice.toLocaleString()})
            </div>
          </div>

          {/* Dismiss */}
          <button
            onClick={() => onDismiss(alert.id)}
            className="w-7 h-7 rounded-full flex items-center justify-center shrink-0"
            style={{ background: "rgba(255,255,255,0.08)", color: "rgba(255,255,255,0.4)" }}
          >
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none">
              <path d="M18 6L6 18M6 6l12 12" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" />
            </svg>
          </button>
        </div>
      ))}
    </div>
  );
}
