"use client";

import { useState } from "react";
import { ChatScreen } from "@/features/crypto-chat/chat-screen";
import { PortfolioScreen } from "@/features/portfolio/portfolio-screen";
import { AlertsScreen } from "@/features/alerts/alerts-screen";
import { AlertToast } from "@/features/alerts/alert-toast";
import { useAlerts } from "@/features/alerts/use-alerts";

type Tab = "chat" | "portfolio" | "alerts";

export function MiniApp() {
  const [tab, setTab] = useState<Tab>("chat");
  const {
    activeAlerts,
    triggeredAlerts,
    triggered,
    isChecking,
    addAlert,
    removeAlert,
    dismissTriggered,
    checkPrices,
  } = useAlerts();

  return (
    <div className="h-dvh flex flex-col overflow-hidden" style={{ background: "#050511" }}>
      {/* Alert toasts */}
      <AlertToast toasts={triggered} onDismiss={dismissTriggered} />

      {/* Tab content */}
      <div className="flex-1 overflow-hidden">
        {tab === "chat" && <ChatScreen />}
        {tab === "portfolio" && <PortfolioScreen />}
        {tab === "alerts" && (
          <AlertsScreen
            onCheckPrices={checkPrices}
            isChecking={isChecking}
            activeAlerts={activeAlerts}
            triggeredAlerts={triggeredAlerts}
            onAdd={addAlert}
            onRemove={removeAlert}
          />
        )}
      </div>

      {/* Bottom tab bar */}
      <nav
        className="shrink-0 flex items-center px-4 pt-2 pb-3 gap-2"
        style={{
          borderTop: "1px solid rgba(255,255,255,0.07)",
          background: "rgba(5,5,17,0.95)",
          backdropFilter: "blur(20px)",
        }}
      >
        <TabButton
          active={tab === "chat"}
          onClick={() => setTab("chat")}
          icon={
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
              <path
                d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"
                stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"
                fill={tab === "chat" ? "currentColor" : "none"} fillOpacity={tab === "chat" ? 0.15 : 0}
              />
            </svg>
          }
          label="Chat"
        />
        <TabButton
          active={tab === "portfolio"}
          onClick={() => setTab("portfolio")}
          icon={
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
              <rect x="2" y="3" width="20" height="14" rx="2"
                stroke="currentColor" strokeWidth="2"
                fill={tab === "portfolio" ? "currentColor" : "none"} fillOpacity={tab === "portfolio" ? 0.15 : 0}
              />
              <path d="M8 21H16M12 17V21" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
            </svg>
          }
          label="Portfolio"
        />
        <TabButton
          active={tab === "alerts"}
          onClick={() => setTab("alerts")}
          badge={activeAlerts.length > 0 ? activeAlerts.length : undefined}
          icon={
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
              <path
                d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"
                stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"
                fill={tab === "alerts" ? "currentColor" : "none"} fillOpacity={tab === "alerts" ? 0.15 : 0}
              />
              <path d="M13.73 21a2 2 0 0 1-3.46 0" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          }
          label="Alerts"
        />
      </nav>
    </div>
  );
}

function TabButton({
  active,
  onClick,
  icon,
  label,
  badge,
}: {
  active: boolean;
  onClick: () => void;
  icon: React.ReactNode;
  label: string;
  badge?: number;
}) {
  return (
    <button
      onClick={onClick}
      className="flex-1 flex flex-col items-center gap-1 py-2 rounded-2xl transition-all duration-200 active:scale-95 relative"
      style={
        active
          ? {
              background: "linear-gradient(135deg, rgba(59,130,246,0.2), rgba(139,92,246,0.2))",
              border: "1px solid rgba(99,102,241,0.35)",
              color: "white",
            }
          : {
              background: "transparent",
              border: "1px solid transparent",
              color: "rgba(255,255,255,0.35)",
            }
      }
    >
      <div className="relative">
        {icon}
        {badge !== undefined && badge > 0 && (
          <div
            className="absolute -top-1.5 -right-1.5 w-4 h-4 rounded-full flex items-center justify-center text-white font-bold"
            style={{ fontSize: 9, background: "#6366f1", boxShadow: "0 0 8px rgba(99,102,241,0.8)" }}
          >
            {badge > 9 ? "9+" : badge}
          </div>
        )}
      </div>
      <span className="text-xs font-semibold">{label}</span>
    </button>
  );
}
