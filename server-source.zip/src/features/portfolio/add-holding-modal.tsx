"use client";

import { useState, useEffect } from "react";
import { Holding } from "@/features/portfolio/use-portfolio";

interface AddHoldingModalProps {
  onAdd: (holding: Omit<Holding, "id">) => void;
  onClose: () => void;
  editing?: Holding | null;
  onUpdate?: (id: string, updates: Partial<Omit<Holding, "id">>) => void;
}

const POPULAR_COINS = [
  { symbol: "BTC", name: "Bitcoin", coinId: "bitcoin", image: "https://coin-images.coingecko.com/coins/images/1/small/bitcoin.png" },
  { symbol: "ETH", name: "Ethereum", coinId: "ethereum", image: "https://coin-images.coingecko.com/coins/images/279/small/ethereum.png" },
  { symbol: "SOL", name: "Solana", coinId: "solana", image: "https://coin-images.coingecko.com/coins/images/4128/small/solana.png" },
  { symbol: "BNB", name: "BNB", coinId: "binancecoin", image: "https://coin-images.coingecko.com/coins/images/825/small/bnb-icon2_2x.png" },
  { symbol: "XRP", name: "XRP", coinId: "ripple", image: "https://coin-images.coingecko.com/coins/images/44/small/xrp-symbol-white-128.png" },
  { symbol: "ADA", name: "Cardano", coinId: "cardano", image: "https://coin-images.coingecko.com/coins/images/975/small/cardano.png" },
  { symbol: "AVAX", name: "Avalanche", coinId: "avalanche-2", image: "https://coin-images.coingecko.com/coins/images/12559/small/Avalanche_Circle_RedWhite_Trans.png" },
  { symbol: "DOT", name: "Polkadot", coinId: "polkadot", image: "https://coin-images.coingecko.com/coins/images/12171/small/polkadot.png" },
  { symbol: "DOGE", name: "Dogecoin", coinId: "dogecoin", image: "https://coin-images.coingecko.com/coins/images/5/small/dogecoin.png" },
  { symbol: "LINK", name: "Chainlink", coinId: "chainlink", image: "https://coin-images.coingecko.com/coins/images/877/small/chainlink-new-logo.png" },
  { symbol: "UNI", name: "Uniswap", coinId: "uniswap", image: "https://coin-images.coingecko.com/coins/images/12504/small/uni.jpg" },
  { symbol: "MATIC", name: "Polygon", coinId: "matic-network", image: "https://coin-images.coingecko.com/coins/images/4713/small/matic-token-icon.png" },
];

export function AddHoldingModal({ onAdd, onClose, editing, onUpdate }: AddHoldingModalProps) {
  const [selected, setSelected] = useState<typeof POPULAR_COINS[0] | null>(null);
  const [amount, setAmount] = useState("");
  const [buyPrice, setBuyPrice] = useState("");
  const [search, setSearch] = useState("");
  const [step, setStep] = useState<"pick" | "amount">("pick");

  useEffect(() => {
    if (editing) {
      const coin = POPULAR_COINS.find((c) => c.coinId === editing.coinId) ?? {
        symbol: editing.symbol,
        name: editing.name,
        coinId: editing.coinId,
        image: editing.image ?? "",
      };
      setSelected(coin);
      setAmount(String(editing.amount));
      setBuyPrice(String(editing.avgBuyPrice));
      setStep("amount");
    }
  }, [editing]);

  const filtered = POPULAR_COINS.filter(
    (c) =>
      c.symbol.toLowerCase().includes(search.toLowerCase()) ||
      c.name.toLowerCase().includes(search.toLowerCase())
  );

  function handleSubmit() {
    if (!selected || !amount || !buyPrice) return;
    const holding = {
      symbol: selected.symbol,
      name: selected.name,
      coinId: selected.coinId,
      image: selected.image,
      amount: parseFloat(amount),
      avgBuyPrice: parseFloat(buyPrice),
    };
    if (editing && onUpdate) {
      onUpdate(editing.id, holding);
    } else {
      onAdd(holding);
    }
    onClose();
  }

  return (
    <div
      className="fixed inset-0 z-50 flex items-end justify-center"
      style={{ background: "rgba(0,0,0,0.7)", backdropFilter: "blur(8px)" }}
      onClick={(e) => e.target === e.currentTarget && onClose()}
    >
      <div
        className="w-full max-w-[424px] rounded-t-3xl pb-8"
        style={{
          background: "linear-gradient(180deg, #0d0d20 0%, #080814 100%)",
          border: "1px solid rgba(255,255,255,0.1)",
          borderBottom: "none",
          maxHeight: "85vh",
          overflow: "hidden",
          display: "flex",
          flexDirection: "column",
        }}
      >
        {/* Handle + header */}
        <div className="px-5 pt-3 pb-4 shrink-0">
          <div className="w-10 h-1 rounded-full bg-white/20 mx-auto mb-4" />
          <div className="flex items-center justify-between">
            <h2 className="text-white font-bold text-lg">
              {editing ? "Edit Holding" : step === "pick" ? "Choose Coin" : "Add Details"}
            </h2>
            <button
              onClick={onClose}
              className="w-8 h-8 rounded-xl flex items-center justify-center"
              style={{ background: "rgba(255,255,255,0.07)" }}
            >
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none">
                <path d="M18 6L6 18M6 6L18 18" stroke="white" strokeWidth="2.5" strokeLinecap="round" />
              </svg>
            </button>
          </div>
        </div>

        {step === "pick" ? (
          <div className="flex flex-col flex-1 overflow-hidden px-5">
            {/* Search */}
            <div
              className="flex items-center gap-2 px-3 py-2.5 rounded-xl mb-3 shrink-0"
              style={{ background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.08)" }}
            >
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" className="shrink-0">
                <circle cx="11" cy="11" r="8" stroke="rgba(255,255,255,0.4)" strokeWidth="2" />
                <path d="M21 21L16.65 16.65" stroke="rgba(255,255,255,0.4)" strokeWidth="2" strokeLinecap="round" />
              </svg>
              <input
                type="text"
                placeholder="Search coin..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="bg-transparent text-white text-sm outline-none flex-1 placeholder:text-white/30"
                autoFocus
              />
            </div>

            {/* Coin list */}
            <div className="overflow-y-auto flex-1 -mx-1 space-y-1 pb-2">
              {filtered.map((coin) => (
                <button
                  key={coin.coinId}
                  onClick={() => { setSelected(coin); setStep("amount"); }}
                  className="w-full flex items-center gap-3 px-3 py-3 rounded-2xl transition-all active:scale-98"
                  style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.06)" }}
                >
                  <img src={coin.image} alt={coin.symbol} className="w-9 h-9 rounded-full" />
                  <div className="text-left">
                    <p className="text-white font-semibold text-sm">{coin.symbol}</p>
                    <p className="text-white/40 text-xs">{coin.name}</p>
                  </div>
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" className="ml-auto shrink-0">
                    <path d="M9 18L15 12L9 6" stroke="rgba(255,255,255,0.3)" strokeWidth="2" strokeLinecap="round" />
                  </svg>
                </button>
              ))}
            </div>
          </div>
        ) : (
          <div className="px-5 flex flex-col gap-4 flex-1">
            {/* Selected coin */}
            {selected && (
              <div
                className="flex items-center gap-3 px-4 py-3 rounded-2xl"
                style={{ background: "rgba(99,102,241,0.1)", border: "1px solid rgba(99,102,241,0.25)" }}
              >
                <img src={selected.image} alt={selected.symbol} className="w-10 h-10 rounded-full" />
                <div>
                  <p className="text-white font-bold">{selected.symbol}</p>
                  <p className="text-white/50 text-xs">{selected.name}</p>
                </div>
                {!editing && (
                  <button
                    onClick={() => setStep("pick")}
                    className="ml-auto text-blue-400 text-xs font-semibold"
                  >
                    Change
                  </button>
                )}
              </div>
            )}

            {/* Amount */}
            <div>
              <label className="text-white/50 text-xs font-medium mb-1.5 block">
                Amount (how many coins you hold)
              </label>
              <input
                type="number"
                placeholder="e.g. 0.5"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="w-full px-4 py-3.5 rounded-2xl text-white text-sm outline-none"
                style={{
                  background: "rgba(255,255,255,0.06)",
                  border: "1px solid rgba(255,255,255,0.1)",
                }}
                inputMode="decimal"
                autoFocus={!editing}
              />
            </div>

            {/* Avg buy price */}
            <div>
              <label className="text-white/50 text-xs font-medium mb-1.5 block">
                Avg. Buy Price (USD)
              </label>
              <input
                type="number"
                placeholder="e.g. 45000"
                value={buyPrice}
                onChange={(e) => setBuyPrice(e.target.value)}
                className="w-full px-4 py-3.5 rounded-2xl text-white text-sm outline-none"
                style={{
                  background: "rgba(255,255,255,0.06)",
                  border: "1px solid rgba(255,255,255,0.1)",
                }}
                inputMode="decimal"
              />
            </div>

            {/* Preview */}
            {amount && buyPrice && (
              <div
                className="px-4 py-3 rounded-2xl flex justify-between items-center"
                style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.06)" }}
              >
                <span className="text-white/50 text-xs">Total Cost</span>
                <span className="text-white font-bold text-sm">
                  ${(parseFloat(amount || "0") * parseFloat(buyPrice || "0")).toLocaleString("en-US", { maximumFractionDigits: 2 })}
                </span>
              </div>
            )}

            {/* Submit */}
            <button
              onClick={handleSubmit}
              disabled={!amount || !buyPrice || parseFloat(amount) <= 0 || parseFloat(buyPrice) <= 0}
              className="w-full py-4 rounded-2xl text-white font-bold text-sm transition-all active:scale-95 disabled:opacity-40"
              style={{
                background: "linear-gradient(135deg, #3B82F6, #6366f1, #8B5CF6)",
                boxShadow: "0 4px 20px rgba(99,102,241,0.4)",
              }}
            >
              {editing ? "Update Holding" : "Add to Portfolio"}
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
