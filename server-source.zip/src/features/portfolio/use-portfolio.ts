"use client";

import { useState, useEffect, useCallback } from "react";

export interface Holding {
  id: string;
  symbol: string;
  name: string;
  coinId: string;
  amount: number;
  avgBuyPrice: number;
  image?: string;
}

export interface HoldingWithPrice extends Holding {
  currentPrice: number;
  currentValue: number;
  pnl: number;
  pnlPercent: number;
  change24h: number;
}

export interface PortfolioSummary {
  totalValue: number;
  totalCost: number;
  totalPnl: number;
  totalPnlPercent: number;
  holdings: HoldingWithPrice[];
}

const STORAGE_KEY = "cryptomind_portfolio";

function loadHoldings(): Holding[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

function saveHoldings(holdings: Holding[]) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(holdings));
  } catch {}
}

export function usePortfolio() {
  const [holdings, setHoldings] = useState<Holding[]>([]);
  const [prices, setPrices] = useState<Record<string, { price: number; change24h: number }>>({});
  const [loadingPrices, setLoadingPrices] = useState(false);

  // Load from localStorage on mount
  useEffect(() => {
    setHoldings(loadHoldings());
  }, []);

  // Fetch live prices for all held coins
  const refreshPrices = useCallback(async (h: Holding[]) => {
    if (!h.length) return;
    setLoadingPrices(true);
    try {
      const ids = [...new Set(h.map((x) => x.coinId))].join(",");
      const res = await fetch(
        `/api/coingecko/coins/markets?vs_currency=usd&ids=${ids}&order=market_cap_desc&per_page=50&page=1&sparkline=false&price_change_percentage=24h`
      );
      if (!res.ok) return;
      const data = await res.json();
      const map: Record<string, { price: number; change24h: number }> = {};
      for (const coin of data) {
        map[coin.id] = {
          price: coin.current_price ?? 0,
          change24h: coin.price_change_percentage_24h ?? 0,
        };
      }
      setPrices(map);
    } catch {
      // silently fail
    } finally {
      setLoadingPrices(false);
    }
  }, []);

  useEffect(() => {
    if (holdings.length) refreshPrices(holdings);
  }, [holdings, refreshPrices]);

  const addHolding = useCallback((holding: Omit<Holding, "id">) => {
    const newHolding: Holding = { ...holding, id: Math.random().toString(36).slice(2) };
    setHoldings((prev) => {
      const updated = [...prev, newHolding];
      saveHoldings(updated);
      return updated;
    });
  }, []);

  const updateHolding = useCallback((id: string, updates: Partial<Omit<Holding, "id">>) => {
    setHoldings((prev) => {
      const updated = prev.map((h) => (h.id === id ? { ...h, ...updates } : h));
      saveHoldings(updated);
      return updated;
    });
  }, []);

  const removeHolding = useCallback((id: string) => {
    setHoldings((prev) => {
      const updated = prev.filter((h) => h.id !== id);
      saveHoldings(updated);
      return updated;
    });
  }, []);

  const summary: PortfolioSummary = (() => {
    const holdingsWithPrice: HoldingWithPrice[] = holdings.map((h) => {
      const liveData = prices[h.coinId];
      const currentPrice = liveData?.price ?? h.avgBuyPrice;
      const currentValue = currentPrice * h.amount;
      const cost = h.avgBuyPrice * h.amount;
      const pnl = currentValue - cost;
      const pnlPercent = cost > 0 ? (pnl / cost) * 100 : 0;
      return {
        ...h,
        currentPrice,
        currentValue,
        pnl,
        pnlPercent,
        change24h: liveData?.change24h ?? 0,
      };
    });

    const totalValue = holdingsWithPrice.reduce((s, h) => s + h.currentValue, 0);
    const totalCost = holdingsWithPrice.reduce((s, h) => s + h.avgBuyPrice * h.amount, 0);
    const totalPnl = totalValue - totalCost;
    const totalPnlPercent = totalCost > 0 ? (totalPnl / totalCost) * 100 : 0;

    return { totalValue, totalCost, totalPnl, totalPnlPercent, holdings: holdingsWithPrice };
  })();

  return { holdings, summary, loadingPrices, addHolding, updateHolding, removeHolding, refreshPrices };
}
