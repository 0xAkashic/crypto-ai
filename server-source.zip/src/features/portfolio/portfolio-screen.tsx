"use client";

import { useState, useMemo } from "react";
import { usePortfolio, Holding, HoldingWithPrice } from "@/features/portfolio/use-portfolio";
import { AddHoldingModal } from "@/features/portfolio/add-holding-modal";

function fmt(n: number, decimals = 2) {
  return n.toLocaleString("en-US", { minimumFractionDigits: decimals, maximumFractionDigits: decimals });
}
function fmtPrice(n: number) {
  if (n >= 1000) return "$" + fmt(n, 2);
  if (n >= 1) return "$" + fmt(n, 4);
  return "$" + n.toFixed(6);
}
function fmtCompact(n: number) {
  if (n >= 1_000_000) return "$" + (n / 1_000_000).toFixed(2) + "M";
  if (n >= 1_000) return "$" + (n / 1_000).toFixed(1) + "K";
  return "$" + fmt(n);
}

// Coin accent colors for donut + bars
const COIN_COLORS = [
  "#F7931A", // BTC orange
  "#627EEA", // ETH purple
  "#9945FF", // SOL purple
  "#F0B90B", // BNB yellow
  "#00AAE4", // XRP blue
  "#0033AD", // ADA blue
  "#E84142", // AVAX red
  "#E6007A", // DOT pink
  "#C2A633", // DOGE gold
  "#375BD2", // LINK blue
  "#FF007A", // UNI pink
  "#8247E5", // MATIC purple
];

// SVG Donut chart
function DonutChart({ holdings, totalValue }: { holdings: HoldingWithPrice[]; totalValue: number }) {
  const SIZE = 120;
  const STROKE = 14;
  const R = (SIZE - STROKE) / 2;
  const CIRC = 2 * Math.PI * R;
  const cx = SIZE / 2;
  const cy = SIZE / 2;

  const slices = useMemo(() => {
    let offset = -0.25 * CIRC; // start at top
    return holdings.map((h, i) => {
      const pct = totalValue > 0 ? h.currentValue / totalValue : 0;
      const dash = pct * CIRC;
      const gap = CIRC - dash;
      const slice = { offset, dash, gap, color: COIN_COLORS[i % COIN_COLORS.length] };
      offset += dash;
      return slice;
    });
  }, [holdings, totalValue, CIRC]);

  if (holdings.length === 0) return null;

  return (
    <div className="relative flex items-center justify-center" style={{ width: SIZE, height: SIZE }}>
      <svg width={SIZE} height={SIZE} style={{ transform: "rotate(0deg)" }}>
        {/* Background ring */}
        <circle cx={cx} cy={cy} r={R} fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth={STROKE} />
        {slices.map((s, i) => (
          <circle
            key={i}
            cx={cx} cy={cy} r={R}
            fill="none"
            stroke={s.color}
            strokeWidth={STROKE}
            strokeDasharray={`${s.dash} ${s.gap}`}
            strokeDashoffset={-s.offset}
            strokeLinecap="butt"
          />
        ))}
      </svg>
      {/* Center label */}
      <div className="absolute flex flex-col items-center justify-center">
        <span className="text-white font-black text-sm leading-tight">{fmtCompact(totalValue)}</span>
        <span className="text-white/40 text-[10px]">{holdings.length} coins</span>
      </div>
    </div>
  );
}

// Allocation bar for each coin
function AllocationBar({ holding, totalValue, index }: { holding: HoldingWithPrice; index: number; totalValue: number }) {
  const pct = totalValue > 0 ? (holding.currentValue / totalValue) * 100 : 0;
  const color = COIN_COLORS[index % COIN_COLORS.length];
  const isUp = holding.pnl >= 0;
  const is24hUp = holding.change24h >= 0;

  return (
    <div className="rounded-2xl px-4 py-3.5 relative overflow-hidden"
      style={{ background: "rgba(255,255,255,0.035)", border: "1px solid rgba(255,255,255,0.07)" }}
    >
      {/* Subtle left accent */}
      <div className="absolute left-0 top-3 bottom-3 w-0.5 rounded-full" style={{ background: color }} />

      <div className="flex items-center gap-3 mb-2.5">
        {/* Icon */}
        <div className="relative shrink-0">
          {holding.image ? (
            <img src={holding.image} alt={holding.symbol} className="w-9 h-9 rounded-full" />
          ) : (
            <div className="w-9 h-9 rounded-full flex items-center justify-center text-xs font-bold text-white"
              style={{ background: color + "33", border: `1px solid ${color}55` }}>
              {holding.symbol.slice(0, 2)}
            </div>
          )}
        </div>

        {/* Name & price */}
        <div className="flex-1 min-w-0">
          <div className="flex items-center justify-between">
            <span className="text-white font-bold text-sm">{holding.symbol}</span>
            <span className="text-white font-bold text-sm">${fmt(holding.currentValue)}</span>
          </div>
          <div className="flex items-center justify-between mt-0.5">
            <span className="text-white/40 text-xs">{holding.amount} · {fmtPrice(holding.currentPrice)}</span>
            <div className="flex items-center gap-2">
              <span className="text-xs font-semibold" style={{ color: is24hUp ? "#4ade80" : "#f87171" }}>
                {is24hUp ? "▲" : "▼"} {Math.abs(holding.change24h).toFixed(2)}%
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Allocation bar */}
      <div className="h-1.5 rounded-full mb-2" style={{ background: "rgba(255,255,255,0.07)" }}>
        <div
          className="h-full rounded-full transition-all duration-700"
          style={{ width: `${Math.max(pct, 1)}%`, background: `linear-gradient(90deg, ${color}cc, ${color})` }}
        />
      </div>

      {/* Stats row */}
      <div className="flex items-center justify-between">
        <span className="text-white/30 text-xs">{pct.toFixed(1)}% of portfolio</span>
        <div className="flex items-center gap-3">
          <span className="text-white/30 text-xs">P&L</span>
          <span className="text-xs font-semibold" style={{ color: isUp ? "#4ade80" : "#f87171" }}>
            {isUp ? "+" : ""}${fmt(holding.pnl)}
          </span>
        </div>
      </div>
    </div>
  );
}

export function PortfolioScreen() {
  const { summary, loadingPrices, addHolding, updateHolding, removeHolding, refreshPrices, holdings } = usePortfolio();
  const [showModal, setShowModal] = useState(false);
  const [editing, setEditing] = useState<Holding | null>(null);
  const [expandedId, setExpandedId] = useState<string | null>(null);

  const isProfit = summary.totalPnl >= 0;
  const hasHoldings = summary.holdings.length > 0;

  // Sort by value descending
  const sortedHoldings = useMemo(
    () => [...summary.holdings].sort((a, b) => b.currentValue - a.currentValue),
    [summary.holdings]
  );

  // Best & worst performer
  const best = sortedHoldings.reduce<HoldingWithPrice | null>((acc, h) => !acc || h.pnlPercent > acc.pnlPercent ? h : acc, null);
  const worst = sortedHoldings.reduce<HoldingWithPrice | null>((acc, h) => !acc || h.pnlPercent < acc.pnlPercent ? h : acc, null);

  return (
    <div className="flex flex-col h-full overflow-hidden" style={{ background: "#050511" }}>

      {/* ── HEADER ── */}
      <header className="shrink-0 px-4 pt-3 pb-2 flex items-center justify-between"
        style={{ borderBottom: "1px solid rgba(255,255,255,0.06)" }}>
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg flex items-center justify-center text-sm"
            style={{ background: "linear-gradient(135deg,#3B82F6,#8B5CF6)", boxShadow: "0 0 12px rgba(99,102,241,0.5)" }}>
            📊
          </div>
          <span className="text-white font-black text-sm tracking-tight">Portfolio</span>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => refreshPrices(holdings)}
            disabled={loadingPrices}
            className="w-8 h-8 rounded-xl flex items-center justify-center transition-all active:scale-90 disabled:opacity-40"
            style={{ background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.08)" }}
          >
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none"
              style={loadingPrices ? { animation: "spin 0.8s linear infinite" } : {}}>
              <path d="M1 4V10H7" stroke="rgba(255,255,255,0.7)" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
              <path d="M3.51 15a9 9 0 1 0 .49-4.51" stroke="rgba(255,255,255,0.7)" strokeWidth="2.5" strokeLinecap="round" />
            </svg>
          </button>
          <button
            onClick={() => { setEditing(null); setShowModal(true); }}
            className="h-8 px-3 rounded-xl text-white font-bold text-xs flex items-center gap-1.5 transition-all active:scale-95"
            style={{ background: "linear-gradient(135deg,#3B82F6,#6366f1,#8B5CF6)", boxShadow: "0 2px 12px rgba(99,102,241,0.35)" }}
          >
            <span className="text-base leading-none">+</span> Add
          </button>
        </div>
      </header>

      <div className="flex-1 overflow-y-auto">
        {!hasHoldings ? (
          /* ── EMPTY STATE ── */
          <div className="flex flex-col items-center justify-center py-16 gap-5 px-6">
            <div className="relative">
              <div className="w-24 h-24 rounded-3xl flex items-center justify-center text-5xl"
                style={{ background: "rgba(99,102,241,0.1)", border: "1px solid rgba(99,102,241,0.2)" }}>
                📊
              </div>
              <div className="absolute -bottom-1 -right-1 w-8 h-8 rounded-xl flex items-center justify-center text-lg"
                style={{ background: "linear-gradient(135deg,#3B82F6,#8B5CF6)" }}>
                +
              </div>
            </div>
            <div className="text-center">
              <p className="text-white font-bold text-lg mb-2">Track your portfolio</p>
              <p className="text-white/40 text-sm leading-relaxed">Add your crypto holdings to see total value, P&L, and allocation breakdown</p>
            </div>
            <button
              onClick={() => setShowModal(true)}
              className="px-8 py-3.5 rounded-2xl text-white font-bold text-sm active:scale-95 transition-transform"
              style={{ background: "linear-gradient(135deg,#3B82F6,#6366f1,#8B5CF6)", boxShadow: "0 4px 20px rgba(99,102,241,0.4)" }}
            >
              + Add First Holding
            </button>
          </div>
        ) : (
          <div className="px-4 py-3 space-y-3 pb-6">

            {/* ── HERO CARD: Value + Donut ── */}
            <div className="rounded-3xl p-4 relative overflow-hidden"
              style={{
                background: "linear-gradient(135deg, rgba(59,130,246,0.12) 0%, rgba(99,102,241,0.18) 50%, rgba(139,92,246,0.12) 100%)",
                border: "1px solid rgba(99,102,241,0.25)",
                boxShadow: "0 8px 32px rgba(0,0,0,0.4)",
              }}>
              {/* glow orbs */}
              <div className="absolute -top-10 -right-10 w-36 h-36 rounded-full pointer-events-none"
                style={{ background: "radial-gradient(circle, rgba(99,102,241,0.2) 0%, transparent 70%)" }} />
              <div className="absolute -bottom-8 -left-8 w-28 h-28 rounded-full pointer-events-none"
                style={{ background: "radial-gradient(circle, rgba(59,130,246,0.15) 0%, transparent 70%)" }} />

              <div className="flex items-center gap-4 relative">
                <DonutChart holdings={sortedHoldings} totalValue={summary.totalValue} />

                <div className="flex-1 min-w-0">
                  <p className="text-white/50 text-xs uppercase tracking-wider mb-0.5">Total Value</p>
                  <div className="flex items-center gap-2 mb-1">
                    <h2 className="text-white font-black text-2xl tracking-tight">${fmt(summary.totalValue)}</h2>
                    {loadingPrices && (
                      <div className="w-3 h-3 rounded-full border-2 border-blue-400 border-t-transparent"
                        style={{ animation: "spin 0.8s linear infinite" }} />
                    )}
                  </div>

                  {/* PNL badge */}
                  <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-bold mb-2"
                    style={{
                      background: isProfit ? "rgba(34,197,94,0.15)" : "rgba(239,68,68,0.15)",
                      border: `1px solid ${isProfit ? "rgba(34,197,94,0.3)" : "rgba(239,68,68,0.3)"}`,
                      color: isProfit ? "#4ade80" : "#f87171",
                    }}>
                    {isProfit ? "▲" : "▼"} {isProfit ? "+" : ""}{fmt(summary.totalPnlPercent)}%
                  </div>
                  <p className="text-white/40 text-xs">
                    {isProfit ? "+" : ""}${fmt(summary.totalPnl)} all time
                  </p>
                  <p className="text-white/25 text-xs mt-0.5">
                    Cost basis ${fmt(summary.totalCost)}
                  </p>
                </div>
              </div>

              {/* Color legend dots */}
              <div className="flex flex-wrap gap-x-3 gap-y-1.5 mt-3 pt-3"
                style={{ borderTop: "1px solid rgba(255,255,255,0.07)" }}>
                {sortedHoldings.map((h, i) => (
                  <div key={h.id} className="flex items-center gap-1">
                    <div className="w-2 h-2 rounded-full shrink-0"
                      style={{ background: COIN_COLORS[i % COIN_COLORS.length] }} />
                    <span className="text-white/50 text-xs">{h.symbol}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* ── BEST / WORST ── */}
            {sortedHoldings.length >= 2 && (
              <div className="grid grid-cols-2 gap-2">
                {best && (
                  <div className="rounded-2xl p-3"
                    style={{ background: "rgba(34,197,94,0.07)", border: "1px solid rgba(34,197,94,0.18)" }}>
                    <p className="text-green-400/60 text-xs mb-1">🏆 Best</p>
                    <div className="flex items-center gap-1.5">
                      {best.image && <img src={best.image} alt={best.symbol} className="w-5 h-5 rounded-full" />}
                      <span className="text-white font-bold text-sm">{best.symbol}</span>
                    </div>
                    <p className="text-green-400 font-black text-base mt-0.5">+{fmt(best.pnlPercent)}%</p>
                  </div>
                )}
                {worst && (
                  <div className="rounded-2xl p-3"
                    style={{ background: "rgba(239,68,68,0.07)", border: "1px solid rgba(239,68,68,0.18)" }}>
                    <p className="text-red-400/60 text-xs mb-1">📉 Worst</p>
                    <div className="flex items-center gap-1.5">
                      {worst.image && <img src={worst.image} alt={worst.symbol} className="w-5 h-5 rounded-full" />}
                      <span className="text-white font-bold text-sm">{worst.symbol}</span>
                    </div>
                    <p className="text-red-400 font-black text-base mt-0.5">{fmt(worst.pnlPercent)}%</p>
                  </div>
                )}
              </div>
            )}

            {/* ── HOLDINGS LIST ── */}
            <div>
              <p className="text-white/30 text-xs font-semibold uppercase tracking-wider mb-2">Holdings</p>
              <div className="space-y-2">
                {sortedHoldings.map((h, i) => (
                  <div key={h.id}>
                    <div onClick={() => setExpandedId(expandedId === h.id ? null : h.id)}
                      className="cursor-pointer active:scale-[0.99] transition-transform">
                      <AllocationBar holding={h} totalValue={summary.totalValue} index={i} />
                    </div>

                    {/* Expanded actions */}
                    {expandedId === h.id && (
                      <div className="flex gap-2 mt-1 px-1">
                        <button
                          onClick={() => { setEditing(h); setShowModal(true); setExpandedId(null); }}
                          className="flex-1 py-2.5 rounded-xl text-white/70 text-xs font-semibold flex items-center justify-center gap-1.5 active:scale-95 transition-transform"
                          style={{ background: "rgba(99,102,241,0.12)", border: "1px solid rgba(99,102,241,0.25)" }}
                        >
                          <svg width="11" height="11" viewBox="0 0 24 24" fill="none">
                            <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
                            <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
                          </svg>
                          Edit
                        </button>
                        <button
                          onClick={() => { removeHolding(h.id); setExpandedId(null); }}
                          className="flex-1 py-2.5 rounded-xl text-red-400 text-xs font-semibold flex items-center justify-center gap-1.5 active:scale-95 transition-transform"
                          style={{ background: "rgba(239,68,68,0.08)", border: "1px solid rgba(239,68,68,0.2)" }}
                        >
                          <svg width="11" height="11" viewBox="0 0 24 24" fill="none">
                            <path d="M3 6H21M8 6V4H16V6M19 6L18 20H6L5 6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                          </svg>
                          Remove
                        </button>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>

          </div>
        )}
      </div>

      {/* Modal */}
      {showModal && (
        <AddHoldingModal
          onAdd={addHolding}
          onClose={() => { setShowModal(false); setEditing(null); }}
          editing={editing}
          onUpdate={updateHolding}
        />
      )}
    </div>
  );
}
