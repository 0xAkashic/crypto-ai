/**
 * In-memory cache for CoinGecko API responses.
 *
 * TTLs (time-to-live):
 *   Coin price data  →  60 seconds  (prices change but no need to hammer the API)
 *   Top 10 coins     →  90 seconds  (rankings rarely shift faster)
 *   Trending coins   →  5 minutes   (trending list is very stable short-term)
 *
 * This cuts CoinGecko calls by ~90% under normal chat usage:
 *   - Multiple users asking about BTC → one fetch per 60s shared across all
 *   - "Top gainers?" questions        → one fetch per 90s shared across all
 *   - "What's trending?" questions    → one fetch per 5min shared across all
 */

interface CacheEntry<T> {
  data: T;
  expiresAt: number;
}

class CryptoCache {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  private store = new Map<string, CacheEntry<any>>();

  get<T>(key: string): T | null {
    const entry = this.store.get(key);
    if (!entry) return null;
    if (Date.now() > entry.expiresAt) {
      this.store.delete(key);
      return null;
    }
    return entry.data as T;
  }

  set<T>(key: string, data: T, ttlMs: number): void {
    this.store.set(key, { data, expiresAt: Date.now() + ttlMs });
  }

  /** How many entries are alive right now (for debugging) */
  size(): number {
    const now = Date.now();
    let count = 0;
    for (const entry of this.store.values()) {
      if (now <= entry.expiresAt) count++;
    }
    return count;
  }
}

// Singleton — lives as long as the server process
export const cryptoCache = new CryptoCache();

// TTL constants (milliseconds)
export const TTL = {
  COIN_PRICE:  60_000,   // 60 seconds
  TOP_COINS:   90_000,   // 90 seconds
  TRENDING:   300_000,   // 5 minutes
} as const;
