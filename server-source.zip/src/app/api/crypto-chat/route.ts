import { NextRequest } from "next/server";
import { cryptoCache, TTL } from "@/lib/crypto-cache";

const COINGECKO_BASE = "https://api.coingecko.com/api/v3";

// Comprehensive coin slug mappings (top 100+ coins)
const COIN_SLUGS: Record<string, string> = {
  // Bitcoin
  btc: "bitcoin", bitcoin: "bitcoin",
  // Ethereum
  eth: "ethereum", ethereum: "ethereum",
  // Solana
  sol: "solana", solana: "solana",
  // BNB
  bnb: "binancecoin", "binance coin": "binancecoin", "bnb chain": "binancecoin",
  // XRP
  xrp: "ripple", ripple: "ripple",
  // Cardano
  ada: "cardano", cardano: "cardano",
  // Dogecoin
  doge: "dogecoin", dogecoin: "dogecoin",
  // PEPE
  pepe: "pepe",
  // Shiba Inu
  shib: "shiba-inu", "shiba inu": "shiba-inu", "shiba": "shiba-inu",
  // Avalanche
  avax: "avalanche-2", avalanche: "avalanche-2",
  // Chainlink
  link: "chainlink", chainlink: "chainlink",
  // Polkadot
  dot: "polkadot", polkadot: "polkadot",
  // Polygon
  matic: "matic-network", polygon: "matic-network", pol: "matic-network",
  // Uniswap
  uni: "uniswap", uniswap: "uniswap",
  // Cosmos
  atom: "cosmos", cosmos: "cosmos",
  // Litecoin
  ltc: "litecoin", litecoin: "litecoin",
  // NEAR
  near: "near",
  // Aptos
  apt: "aptos", aptos: "aptos",
  // Arbitrum
  arb: "arbitrum", arbitrum: "arbitrum",
  // Optimism
  op: "optimism", optimism: "optimism",
  // Sui
  sui: "sui",
  // Tron
  trx: "tron", tron: "tron",
  // Toncoin
  ton: "the-open-network", toncoin: "the-open-network",
  // Stellar
  xlm: "stellar", stellar: "stellar",
  // Monero
  xmr: "monero", monero: "monero",
  // Ethereum Classic
  etc: "ethereum-classic", "ethereum classic": "ethereum-classic",
  // Filecoin
  fil: "filecoin", filecoin: "filecoin",
  // Hedera
  hbar: "hedera-hashgraph", hedera: "hedera-hashgraph",
  // VeChain
  vet: "vechain", vechain: "vechain",
  // Internet Computer
  icp: "internet-computer", "internet computer": "internet-computer",
  // Immutable
  imx: "immutable-x", immutable: "immutable-x",
  // Injective
  inj: "injective-protocol", injective: "injective-protocol",
  // Render
  rndr: "render-token", render: "render-token",
  // Fetch.ai
  fet: "fetch-ai", "fetch.ai": "fetch-ai", fetch: "fetch-ai",
  // Mantle
  mnt: "mantle", mantle: "mantle",
  // Sei
  sei: "sei-network",
  // Celestia
  tia: "celestia", celestia: "celestia",
  // Kaspa
  kas: "kaspa", kaspa: "kaspa",
  // Stacks
  stx: "blockstack", stacks: "blockstack",
  // Flow
  flow: "flow",
  // Theta
  theta: "theta-token",
  // Aave
  aave: "aave",
  // Maker
  mkr: "maker", maker: "maker",
  // Compound
  comp: "compound-governance-token", compound: "compound-governance-token",
  // Curve
  crv: "curve-dao-token", curve: "curve-dao-token",
  // Synthetix
  snx: "havven", synthetix: "havven",
  // Lido
  ldo: "lido-dao", lido: "lido-dao",
  // GMX
  gmx: "gmx",
  // dYdX
  dydx: "dydx",
  // 1inch
  "1inch": "1inch",
  // Sandbox
  sand: "the-sandbox", sandbox: "the-sandbox",
  // Decentraland
  mana: "decentraland", decentraland: "decentraland",
  // Axie Infinity
  axs: "axie-infinity", axie: "axie-infinity",
  // Gala
  gala: "gala",
  // Enjin
  enj: "enjincoin", enjin: "enjincoin",
  // Chiliz
  chz: "chiliz", chiliz: "chiliz",
  // WIF (dogwifhat)
  wif: "dogwifcoin", dogwifhat: "dogwifcoin", "dog wif hat": "dogwifcoin",
  // Floki
  floki: "floki",
  // Bonk
  bonk: "bonk",
  // Brett
  brett: "based-brett",
  // Book of Meme
  bome: "book-of-meme",
  // Popcat
  popcat: "popcat",
  // Notcoin
  not: "notcoin", notcoin: "notcoin",
  // Jupiter
  jup: "jupiter-exchange-solana", jupiter: "jupiter-exchange-solana",
  // Pyth
  pyth: "pyth-network",
  // Raydium
  ray: "raydium", raydium: "raydium",
  // Jito
  jto: "jito-governance-token", jito: "jito-governance-token",
  // Worldcoin
  wld: "worldcoin-wld", worldcoin: "worldcoin-wld",
  // Blur
  blur: "blur",
  // Pendle
  pendle: "pendle",
  // EigenLayer
  eigen: "eigenlayer",
  // Ethena
  ena: "ethena", ethena: "ethena",
  // Renzo
  rez: "renzo",
  // ZKsync
  zk: "zksync",
  // LayerZero
  zro: "layerzero",
  // Wormhole
  w: "wormhole",
  // Hyperliquid
  hype: "hyperliquid",
  // Ondo
  ondo: "ondo-finance",
  // Virtuals
  virtual: "virtual-protocol", virtuals: "virtual-protocol",
  // ai16z
  ai16z: "ai16z",
  // Fartcoin
  fartcoin: "fartcoin",
};

const SYSTEM_PROMPT = `You are CryptoMind AI — a brilliant, versatile AI assistant. Think of yourself like a smarter ChatGPT with deep crypto expertise built in.

## LANGUAGE RULE — CRITICAL
Detect the language of the user's message and ALWAYS reply in that EXACT language.
- English → reply in English
- বাংলা → বাংলায় উত্তর দাও
- Español → responde en Español
- हिन्दी → हिन्दी में जवाब दो
- Any other language → reply in that language
Never switch languages mid-reply. If mixed, use the dominant language.

## YOUR PERSONALITY
- Warm, smart, and direct — like a brilliant friend who happens to know everything
- Match the user's tone: casual when they're casual, detailed when they need depth
- Never robotic, never preachy, never add unnecessary disclaimers
- Give real opinions and clear answers — no wishy-washy "it depends" without substance

## YOU CAN HELP WITH ANYTHING
- **Crypto & Web3**: prices, trading analysis, DeFi, NFTs, tokenomics, blockchain concepts
- **Coding**: write, debug, review code in any language — always show working code
- **Science & Math**: physics, chemistry, biology, calculations, formulas
- **General Knowledge**: history, geography, culture, current events, trivia
- **Creative**: writing, poems, stories, brainstorming
- **Life & Career**: advice, productivity, learning, decisions
- **Languages**: translation, grammar, language learning

## HOW TO RESPOND
- For **crypto questions with live data**: give price analysis, market context, key levels
- For **coding questions**: give working code first, explanation after. Use proper code blocks
- For **simple questions**: be concise — 2-3 sentences is fine
- For **complex topics**: use headers and bullet points to organize
- For **casual chat**: just talk naturally, no need for structure

## CRYPTO PRICE RULE — CRITICAL
⚠️ NEVER quote a crypto price from your training data. Your training data is outdated and prices change every second.
- If live market data is provided in [LIVE MARKET DATA] block → use ONLY those prices
- If no live data is provided for a specific coin → say "I don't have the live price right now, try asking again"
- NEVER say things like "Bitcoin is around $X" based on your training knowledge

## CRYPTO ANALYSIS STYLE
When live market data is provided in [LIVE MARKET DATA]:
- Always use the exact price from the live data block
- Give clear directional sentiment (bullish/bearish/neutral)
- Mention key support/resistance if relevant
- Note volume and momentum signals
- Always add: "Not financial advice — DYOR"

## CODING STYLE
- Working code immediately, no preamble
- Inline comments for clarity
- Note edge cases or gotchas after the code
- Use the correct language tag in code blocks

## MATH & FORMULA RULE — CRITICAL
NEVER use LaTeX syntax (no \frac, \times, \left, \right, \text{}, $$, \[, \], etc.).
NEVER use raw formula notation that requires a LaTeX renderer.
Instead, write math in plain readable text:
- Use plain text: "Profit % = ((Current Price - Buy Price) / Buy Price) × 100"
- Use × instead of \times, ÷ instead of \div
- Write fractions as "(numerator / denominator)"
- For simple calculations, just write out the result: "Profit % = (($50,000 - $40,000) / $40,000) × 100 = 25%"
- You may use a code block ONLY for multi-step calculations where indentation helps readability

Be helpful, be real, be brilliant.`;


interface CoinMarketData {
  id: string;
  symbol: string;
  name: string;
  image: string;
  current_price: number;
  price_change_percentage_24h: number;
  market_cap: number;
  total_volume: number;
}

// Detect if a string looks like a contract address (EVM: 0x... or Solana: base58 32-44 chars)
function extractContractAddress(text: string): { address: string; platform: string } | null {
  // EVM address: 0x followed by 40 hex chars
  const evmMatch = text.match(/\b(0x[a-fA-F0-9]{40})\b/);
  if (evmMatch) return { address: evmMatch[1], platform: "ethereum" };

  // Solana address: base58, 32-44 chars (no 0x prefix, only base58 chars)
  const solMatch = text.match(/\b([1-9A-HJ-NP-Za-km-z]{32,44})\b/);
  if (solMatch) return { address: solMatch[1], platform: "solana" };

  return null;
}

// Lookup coin by contract address via CoinGecko
async function fetchCoinByContract(address: string, platform: string): Promise<CoinMarketData | null> {
  const cacheKey = `ca:${address.toLowerCase()}`;
  const cached = cryptoCache.get<CoinMarketData>(cacheKey);
  if (cached) return cached;

  // Try common EVM platforms in order
  const evmPlatforms = ["ethereum", "base", "binance-smart-chain", "polygon-pos", "arbitrum-one", "optimistic-ethereum", "avalanche"];
  const platformsToTry = platform === "solana" ? ["solana"] : evmPlatforms;

  for (const p of platformsToTry) {
    try {
      const res = await fetch(
        `${COINGECKO_BASE}/coins/${p}/contract/${address.toLowerCase()}`,
        { headers: { Accept: "application/json" } }
      );
      if (!res.ok) continue;
      const data = await res.json();
      if (!data?.id) continue;

      // Now fetch market data for this coin id
      const marketData = await fetchCoinData(data.id);
      if (marketData) {
        cryptoCache.set(cacheKey, marketData, TTL.COIN_PRICE);
        return marketData;
      }
    } catch {
      continue;
    }
  }
  return null;
}

// Search CoinGecko for a coin ID by name or symbol (dynamic lookup)
async function searchCoinId(query: string): Promise<string | null> {
  const cacheKey = `search:${query.toLowerCase()}`;
  const cached = cryptoCache.get<string>(cacheKey);
  if (cached) return cached;

  try {
    const res = await fetch(
      `${COINGECKO_BASE}/search?query=${encodeURIComponent(query)}`,
      { headers: { Accept: "application/json" } }
    );
    if (!res.ok) return null;
    const data = await res.json();
    // Pick the top result that matches name or symbol
    const coins: Array<{ id: string; symbol: string; name: string; market_cap_rank: number | null }> =
      data?.coins ?? [];
    if (!coins.length) return null;

    const q = query.toLowerCase();
    // Prefer exact symbol match first, then exact name match, then top result
    const exactSymbol = coins.find((c) => c.symbol.toLowerCase() === q);
    const exactName   = coins.find((c) => c.name.toLowerCase() === q);
    const best = exactSymbol ?? exactName ?? coins[0];

    cryptoCache.set(cacheKey, best.id, TTL.COIN_PRICE);
    return best.id;
  } catch {
    return null;
  }
}

async function fetchCoinData(coinId: string): Promise<CoinMarketData | null> {
  const cacheKey = `coin:${coinId}`;
  const cached = cryptoCache.get<CoinMarketData>(cacheKey);
  if (cached) return cached;

  try {
    const url = `${COINGECKO_BASE}/coins/markets?vs_currency=usd&ids=${coinId}&order=market_cap_desc&per_page=1&page=1&sparkline=false&price_change_percentage=24h`;
    const res = await fetch(url, { headers: { Accept: "application/json" } });
    if (!res.ok) return null;
    const data = await res.json();
    const result: CoinMarketData | null = data?.[0] ?? null;
    if (result) cryptoCache.set(cacheKey, result, TTL.COIN_PRICE);
    return result;
  } catch {
    return null;
  }
}

async function fetchTrendingCoins(): Promise<string> {
  const cacheKey = "trending";
  const cached = cryptoCache.get<string>(cacheKey);
  if (cached) return cached;

  try {
    const res = await fetch(`${COINGECKO_BASE}/search/trending`, {
      headers: { Accept: "application/json" },
    });
    if (!res.ok) return "";
    const data = await res.json();
    const coins = data?.coins?.slice(0, 7)?.map(
      (c: { item: { name: string; symbol: string; data?: { price_change_percentage_24h?: { usd?: number } } } }) =>
        `${c.item.name} (${c.item.symbol.toUpperCase()}) ${
          c.item.data?.price_change_percentage_24h?.usd
            ? (c.item.data.price_change_percentage_24h.usd > 0 ? "+" : "") +
              c.item.data.price_change_percentage_24h.usd.toFixed(1) +
              "%"
            : ""
        }`
    );
    const result = coins?.join(", ") ?? "";
    if (result) cryptoCache.set(cacheKey, result, TTL.TRENDING);
    return result;
  } catch {
    return "";
  }
}

async function fetchTopCoins(): Promise<string> {
  const cacheKey = "top10";
  const cached = cryptoCache.get<string>(cacheKey);
  if (cached) return cached;

  try {
    const res = await fetch(
      `${COINGECKO_BASE}/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=10&page=1&sparkline=false&price_change_percentage=24h`,
      { headers: { Accept: "application/json" } }
    );
    if (!res.ok) return "";
    const data: CoinMarketData[] = await res.json();
    const result = data
      .map(
        (c) =>
          `${c.name} (${c.symbol.toUpperCase()}): $${c.current_price >= 1000 ? c.current_price.toLocaleString("en-US", { maximumFractionDigits: 2 }) : c.current_price.toFixed(4)} (${c.price_change_percentage_24h >= 0 ? "+" : ""}${c.price_change_percentage_24h?.toFixed(2)}% 24h)`
      )
      .join("\n");
    if (result) cryptoCache.set(cacheKey, result, TTL.TOP_COINS);
    return result;
  } catch {
    return "";
  }
}

// Step 1: try static map (instant, no API call)
function detectCoinInStaticMap(text: string): string | null {
  const lower = text.toLowerCase();
  const sorted = Object.entries(COIN_SLUGS).sort(([a], [b]) => b.length - a.length);
  for (const [keyword, slug] of sorted) {
    const escaped = keyword.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    const regex = new RegExp(`(?<![a-z0-9])${escaped}(?![a-z0-9])`, "i");
    if (regex.test(lower)) return slug;
  }
  return null;
}

// Step 2: extract candidate tokens from the message for dynamic search
function extractCoinCandidates(text: string): string[] {
  // Strip common non-coin words
  const stopWords = new Set([
    "price", "what", "is", "the", "of", "for", "about", "tell", "me",
    "how", "much", "does", "cost", "worth", "today", "now", "current",
    "market", "cap", "volume", "token", "coin", "crypto", "buy", "sell",
    "good", "bad", "should", "i", "a", "an", "and", "or", "to", "in",
    "are", "will", "be", "can", "it", "its", "this", "that", "please",
    "my", "your", "our", "their", "was", "were", "has", "have",
    // Bengali stopwords
    "কি", "কোন", "এর", "এই", "আজকে", "এখন", "বলো", "দাও",
  ]);

  // Extract words that look like coin names/tickers (2-20 chars, no common words)
  const words = text
    .replace(/[^a-zA-Z0-9\s]/g, " ")
    .split(/\s+/)
    .map((w) => w.trim())
    .filter((w) => w.length >= 2 && w.length <= 20 && !stopWords.has(w.toLowerCase()));

  // Also try 2-word combos for coins like "shiba inu", "dog wif hat"
  const pairs: string[] = [];
  for (let i = 0; i < words.length - 1; i++) {
    pairs.push(`${words[i]} ${words[i + 1]}`);
  }

  return [...pairs, ...words];
}

// Main resolver: static map first, then dynamic CoinGecko search
async function resolveCoinId(text: string): Promise<string | null> {
  // Fast path: static map
  const staticId = detectCoinInStaticMap(text);
  if (staticId) return staticId;

  // Slow path: dynamic search for unknown coins
  const candidates = extractCoinCandidates(text);
  for (const candidate of candidates) {
    // Skip very generic single words that aren't likely coin names
    if (candidate.length < 2) continue;
    const id = await searchCoinId(candidate);
    if (id) return id;
  }
  return null;
}

// Detect if the message is crypto-related at all
// Only crypto questions should trigger coin lookup + token cards
function isCryptoQuestion(text: string): boolean {
  const cryptoKeywords = [
    // Direct crypto terms
    "crypto", "bitcoin", "ethereum", "solana", "token", "coin", "defi",
    "nft", "blockchain", "wallet", "altcoin", "memecoin", "staking",
    "yield", "airdrop", "dex", "cex", "swap", "liquidity", "dao",
    "web3", "on-chain", "onchain", "gas", "gwei", "satoshi",
    "halving", "bull", "bear", "pump", "dump", "rekt", "hodl", "aping",
    "ath", "atl", "mcap", "tvl", "apr", "apy", "rugpull",
    // Market update phrases
    "market update", "market news", "market today", "market overview",
    "crypto market", "market summary", "market report", "market analysis",
    "today's market", "today market", "market condition",
    // Market data words
    "price", "bullish", "bearish", "pumping", "dumping",
    "gainers", "losers", "market cap", "trading volume",
    "candle", "chart", "rsi", "macd", "support", "resistance",
    // Bengali
    "ক্রিপ্টো", "টোকেন", "কয়েন", "প্রাইস", "দাম", "বিটকয়েন",
    "ইথেরিয়াম", "ব্লকচেইন", "মাইনিং", "স্টেকিং",
    "মার্কেট আপডেট", "আজকের মার্কেট", "মার্কেট", "বাজার আপডেট",
    "আজকের বাজার", "ক্রিপ্টো মার্কেট", "মার্কেট কেমন",
    // Spanish
    "cripto", "precio", "moneda", "mercado", "actualización del mercado",
    // Hindi
    "क्रिप्टो", "बिटकॉइन", "कीमत", "ब्लॉकचेन", "टोकन", "बाजार",
  ];
  const lower = text.toLowerCase();
  const hasCoinSlug = detectCoinInStaticMap(text) !== null;
  return hasCoinSlug || cryptoKeywords.some((k) => lower.includes(k));
}

function detectDataIntent(text: string): boolean {
  const triggers = [
    "price", "bullish", "bearish", "pumping", "dumping", "trending",
    "gainers", "losers", "market cap", "right now", "current price",
    "how much is", "what is the price", "trading at",
    // Bengali
    "দাম", "মূল্য", "প্রাইস", "কত দাম", "এখন কত",
  ];
  const lower = text.toLowerCase();
  return triggers.some((t) => lower.includes(t));
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { messages } = body as {
      messages: Array<{ role: string; content: string }>;
    };

    if (!messages?.length) {
      return new Response("No messages provided", { status: 400 });
    }

    const lastUserMessage = messages.filter((m) => m.role === "user").at(-1)?.content ?? "";
    const lower = lastUserMessage.toLowerCase();

    // Check for contract address first — always treat as crypto question
    const contractMatch = extractContractAddress(lastUserMessage);
    const isCrypto = contractMatch !== null || isCryptoQuestion(lastUserMessage);

    const wantsMarketOverview = isCrypto && (
      lower.includes("market update") || lower.includes("market overview") ||
      lower.includes("market today") || lower.includes("market news") ||
      lower.includes("market summary") || lower.includes("top coin") ||
      lower.includes("gainers") || lower.includes("losers") ||
      lower.includes("মার্কেট") || lower.includes("বাজার") ||
      lower.includes("আজকের") || lower.includes("today market") ||
      lower.includes("market condition") || lower.includes("market analysis")
    );
    const wantsTrending = isCrypto && (lower.includes("trend") || wantsMarketOverview);

    // For ANY crypto question, always resolve coin + fetch live data
    // If message has a contract address, use that directly
    const contractCoinDataPromise = contractMatch && !wantsMarketOverview
      ? fetchCoinByContract(contractMatch.address, contractMatch.platform)
      : Promise.resolve(null);

    const coinId = !contractMatch && isCrypto && !wantsMarketOverview
      ? await resolveCoinId(lastUserMessage)
      : null;

    const [contractCoinData, coinData, trendingData, topCoinsData] = await Promise.all([
      contractCoinDataPromise,
      coinId ? fetchCoinData(coinId) : Promise.resolve(null),
      wantsTrending ? fetchTrendingCoins() : Promise.resolve(""),
      // Fetch top 10 for market overview OR when crypto question but no specific coin/contract
      (wantsMarketOverview || (isCrypto && !coinId && !contractMatch)) ? fetchTopCoins() : Promise.resolve(""),
    ]);

    // Merge: contract address lookup takes priority over name/symbol lookup
    const resolvedCoin = contractCoinData ?? coinData;

    // Build context injection
    let liveContext = "";
    if (contractMatch && !resolvedCoin) {
      liveContext = `\n\n[CONTRACT ADDRESS LOOKUP]\nAddress: ${contractMatch.address}\nResult: No data found on CoinGecko for this contract address. It may be a very new token, unlisted, or the address may be incorrect. Tell the user you couldn't find this token on CoinGecko and suggest verifying the address on Etherscan/Solscan.`;
    } else if (resolvedCoin) {
      const coinData = resolvedCoin;
      liveContext = `\n\n[LIVE MARKET DATA - ${new Date().toUTCString()}]\n${coinData.name} (${coinData.symbol.toUpperCase()}):
- Current Price: $${coinData.current_price >= 1000 ? coinData.current_price.toLocaleString("en-US") : coinData.current_price.toFixed(6)}
- 24h Change: ${coinData.price_change_percentage_24h >= 0 ? "+" : ""}${coinData.price_change_percentage_24h?.toFixed(2)}%
- Market Cap: $${(coinData.market_cap / 1e9).toFixed(2)}B
- 24h Volume: $${(coinData.total_volume / 1e9).toFixed(2)}B
Use this data in your response.`;
    } else if (topCoinsData) {
      liveContext = `\n\n[LIVE MARKET DATA - ${new Date().toUTCString()}]\nTop 10 by Market Cap:\n${topCoinsData}\nUse this data in your response.`;
    }
    if (trendingData) {
      liveContext += `\n\n[TRENDING COINS RIGHT NOW]\n${trendingData}`;
    }

    const systemPrompt = SYSTEM_PROMPT + liveContext;

    // Use Groq (fastest) or OpenAI, fall back to smart built-in responses
    const groqKey = process.env.GROQ_API_KEY;
    const openaiKey = process.env.OPENAI_API_KEY;

    // Pick provider: Groq preferred (faster), then OpenAI, then fallback
    let aiEndpoint = "";
    let aiModel = "";
    let authHeader = "";

    if (groqKey) {
      aiEndpoint = "https://api.groq.com/openai/v1/chat/completions";
      aiModel = "llama-3.3-70b-versatile";
      authHeader = `Bearer ${groqKey}`;
    } else if (openaiKey) {
      aiEndpoint = "https://api.openai.com/v1/chat/completions";
      aiModel = "gpt-4o-mini";
      authHeader = `Bearer ${openaiKey}`;
    } else {
      return buildFallbackResponse(lastUserMessage, coinData);
    }

    const openaiRes = await fetch(aiEndpoint, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: authHeader,
      },
      body: JSON.stringify({
        model: aiModel,
        stream: true,
        max_tokens: 1024,
        temperature: 0.7,
        messages: [
          { role: "system", content: systemPrompt },
          // Keep last 20 messages for memory (10 exchanges) — enough context without hitting limits
          ...messages.slice(-20).map((m) => ({ role: m.role, content: m.content })),
        ],
      }),
    });

    if (!openaiRes.ok) {
      const err = await openaiRes.text();
      console.error("AI provider error:", err);
      return buildFallbackResponse(lastUserMessage, resolvedCoin);
    }

    // Stream the response
    const encoder = new TextEncoder();
    const stream = new ReadableStream({
      async start(controller) {
        // If we have token data, emit it first
        if (resolvedCoin) {
          controller.enqueue(
            encoder.encode(
              `data: ${JSON.stringify({ type: "token_data", data: resolvedCoin })}\n\n`
            )
          );
        }

        const reader = openaiRes.body?.getReader();
        if (!reader) {
          controller.close();
          return;
        }

        const decoder = new TextDecoder();
        let buffer = "";

        try {
          while (true) {
            const { done, value } = await reader.read();
            if (done) break;

            buffer += decoder.decode(value, { stream: true });
            const lines = buffer.split("\n");
            buffer = lines.pop() ?? "";

            for (const line of lines) {
              if (!line.startsWith("data: ")) continue;
              const data = line.slice(6).trim();
              if (data === "[DONE]") {
                controller.enqueue(encoder.encode("data: [DONE]\n\n"));
                controller.close();
                return;
              }
              try {
                const parsed = JSON.parse(data);
                const content = parsed.choices?.[0]?.delta?.content;
                if (content) {
                  controller.enqueue(
                    encoder.encode(
                      `data: ${JSON.stringify({ type: "text", content })}\n\n`
                    )
                  );
                }
              } catch {
                // Skip
              }
            }
          }
        } finally {
          reader.releaseLock();
          controller.close();
        }
      },
    });

    return new Response(stream, {
      headers: {
        "Content-Type": "text/event-stream",
        "Cache-Control": "no-cache",
        Connection: "keep-alive",
      },
    });
  } catch (err) {
    console.error("Chat API error:", err);
    return new Response("Internal server error", { status: 500 });
  }
}

function buildFallbackResponse(
  userMessage: string,
  coinData: CoinMarketData | null
): Response {
  const encoder = new TextEncoder();
  const lower = userMessage.toLowerCase();

  let response = "";

  if (coinData) {
    const change = coinData.price_change_percentage_24h;
    const sentiment = change > 5 ? "strongly bullish" : change > 1 ? "bullish" : change < -5 ? "strongly bearish" : change < -1 ? "bearish" : "relatively neutral";
    response = `**${coinData.name} (${coinData.symbol.toUpperCase()}) — Live Data**\n\n**Price:** $${coinData.current_price >= 1000 ? coinData.current_price.toLocaleString("en-US") : coinData.current_price.toFixed(6)}\n**24h:** ${change >= 0 ? "+" : ""}${change?.toFixed(2)}%\n**Market Cap:** $${(coinData.market_cap / 1e9).toFixed(2)}B\n**Volume:** $${(coinData.total_volume / 1e9).toFixed(2)}B\n\n**Sentiment:** ${sentiment.charAt(0).toUpperCase() + sentiment.slice(1)} — ${change > 0 ? "bulls in control short-term" : "bears currently dominant"}.\n\nVolume is ${coinData.total_volume > coinData.market_cap * 0.1 ? "elevated (high activity)" : "moderate"}. Cap profile: ${coinData.market_cap > 50e9 ? "large-cap" : coinData.market_cap > 1e9 ? "mid-cap" : "small-cap"}.\n\n*Not financial advice — DYOR.*`;
  } else if (lower.includes("defi")) {
    response = `**DeFi (Decentralized Finance) — Explained**\n\nDeFi refers to financial services built on blockchain networks that operate without traditional intermediaries like banks.\n\n**Key DeFi Concepts:**\n- **Lending/Borrowing** — Protocols like Aave, Compound let users lend crypto and earn interest, or borrow against collateral\n- **DEXes** — Decentralized exchanges (Uniswap, Curve) let you swap tokens without a centralized company\n- **Yield Farming** — Providing liquidity to earn rewards (often paid in the protocol's token)\n- **Staking** — Locking tokens to secure a network and earn rewards\n- **TVL** — Total Value Locked, the main metric showing how much capital a DeFi protocol holds\n\n**Top DeFi Chains:** Ethereum, Base, Arbitrum, Solana, Avalanche\n\nDeFi is 24/7, permissionless, and transparent — but also carries smart contract risk. Always audit the protocols you use.\n\n*💡 Tip: Start with battle-tested protocols with audited code and long track records.*`;
  } else if (lower.includes("nft")) {
    response = `**NFTs (Non-Fungible Tokens) — What You Need to Know**\n\nNFTs are unique digital assets stored on a blockchain. Unlike Bitcoin where each coin is identical, each NFT is one-of-a-kind.\n\n**Core Concepts:**\n- **Floor Price** — The cheapest NFT you can buy in a collection\n- **Volume** — Total trading activity (shows market interest)\n- **Rarity** — How unique specific traits are within a collection\n- **Royalties** — Creators earn % on each secondary sale\n\n**Key NFT Marketplaces:**\n- OpenSea, Blur (Ethereum)\n- Magic Eden (Solana, multi-chain)\n- Zora (Base)\n\n**NFT Use Cases Beyond Art:**\n- Gaming items and characters\n- Event tickets and memberships\n- Domain names (ENS)\n- Real-world asset tokenization\n\nThe NFT market is highly speculative. Blue chips (BAYC, CryptoPunks, Azuki) have more liquidity, but even they're volatile.\n\n*⚠️ Most NFTs go to zero. Research communities and utility before buying.*`;
  } else if (lower.includes("staking")) {
    response = `**Crypto Staking — How It Works**\n\nStaking means locking up cryptocurrency to help validate transactions on a Proof-of-Stake blockchain, earning rewards in return.\n\n**How It Works:**\n1. You lock (stake) your tokens\n2. You help validate blocks\n3. You earn APY rewards (paid in the native token)\n\n**Popular Staking Options:**\n- **ETH** — ~3-4% APY via Lido, Rocket Pool, or native staking\n- **SOL** — ~6-7% APY via validators or liquid staking (mSOL, jitoSOL)\n- **ATOM** — ~15-20% APY (high inflation, check real yield)\n- **DOT** — ~12-15% APY\n\n**Liquid Staking:**\nGet a receipt token (stETH, mSOL) that you can use in DeFi while still earning staking rewards. Best of both worlds.\n\n**Risks:**\n- Slashing (rare — validator misbehavior)\n- Lock-up periods\n- Token price risk (APY doesn't protect from price drops)\n\n*💡 Stick to liquid staking for flexibility.*`;
  } else if (lower.includes("blockchain") || lower.includes("explain")) {
    response = `**Blockchain — The Foundation of Crypto**\n\nA blockchain is a distributed database shared across thousands of computers (nodes). It records transactions in "blocks" that are chained together — making the history tamper-proof.\n\n**Key Properties:**\n- **Decentralized** — No single company controls it\n- **Transparent** — Anyone can view all transactions\n- **Immutable** — Once recorded, data cannot be changed\n- **Permissionless** — Anyone can use it\n\n**Major Blockchains:**\n- **Bitcoin** — First and largest, digital gold store of value\n- **Ethereum** — Smart contracts platform, DeFi/NFT hub\n- **Solana** — Fast & cheap, growing ecosystem\n- **Base** — Ethereum L2, Coinbase-backed, low fees\n\n**Consensus Mechanisms:**\n- **Proof of Work** — Mining (Bitcoin)\n- **Proof of Stake** — Staking validators (Ethereum, Solana)\n\nBlockchain technology enables trustless, programmable money — the foundation of the entire crypto ecosystem.`;
  } else {
    response = `I'm **CryptoMind AI** — your intelligent crypto research assistant! 🚀\n\nI can help you with:\n- **Live prices** — Ask "What's BTC price?" or "Is ETH bullish?"\n- **Market analysis** — Technical and fundamental insights\n- **DeFi** — Yield farming, staking, liquidity pools\n- **NFTs** — Collections, floor prices, market trends\n- **Blockchain basics** — How it all works\n- **Token research** — Deep dives on any project\n\n**Try asking:**\n- "What are the top gainers today?"\n- "Explain Ethereum Layer 2s"\n- "Is now a good time to buy SOL?"\n- "What is tokenomics?"\n\n*💡 To unlock real AI responses, add your OpenAI API key to the environment.*`;
  }

  const stream = new ReadableStream({
    start(controller) {
      if (coinData) {
        controller.enqueue(
          encoder.encode(
            `data: ${JSON.stringify({ type: "token_data", data: coinData })}\n\n`
          )
        );
      }
      // Stream word by word for effect
      const words = response.split(" ");
      let i = 0;
      const interval = setInterval(() => {
        if (i >= words.length) {
          controller.enqueue(encoder.encode("data: [DONE]\n\n"));
          controller.close();
          clearInterval(interval);
          return;
        }
        const chunk = (i === 0 ? "" : " ") + words[i];
        controller.enqueue(
          encoder.encode(
            `data: ${JSON.stringify({ type: "text", content: chunk })}\n\n`
          )
        );
        i++;
      }, 15);
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache",
      Connection: "keep-alive",
    },
  });
}
