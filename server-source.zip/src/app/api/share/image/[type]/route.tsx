import { NextRequest } from "next/server";
import { publicConfig } from "@/config/public-config";
import { getShareImageResponse } from "@/neynar-farcaster-sdk/nextjs";

// Cache for 1 hour - query strings create separate cache entries
export const revalidate = 3600;

const { appEnv, heroImageUrl, imageUrl } = publicConfig;

const showDevWarning = appEnv !== "production";

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ type: string }> },
) {
  const { type } = await params;

  return getShareImageResponse(
    { type, heroImageUrl, imageUrl, showDevWarning },
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        width: "100%",
        height: "100%",
        position: "relative",
        overflow: "hidden",
        background: "linear-gradient(145deg, #03020f 0%, #080720 50%, #0c0528 100%)",
        fontFamily: "sans-serif",
      }}
    >
      {/* Background glow top-left */}
      <div style={{ display: "flex", position: "absolute", top: -200, left: -200, width: 700, height: 700, borderRadius: "50%", background: "radial-gradient(circle, rgba(99,102,241,0.2) 0%, transparent 65%)" }} />
      {/* Background glow bottom-right */}
      <div style={{ display: "flex", position: "absolute", bottom: -200, right: -200, width: 700, height: 700, borderRadius: "50%", background: "radial-gradient(circle, rgba(139,92,246,0.2) 0%, transparent 65%)" }} />

      {/* Centered content */}
      <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 32, position: "relative", zIndex: 2 }}>

        {/* Logo icon */}
        <div style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          width: 120,
          height: 120,
          borderRadius: 32,
          background: "linear-gradient(135deg, #3B82F6 0%, #6366f1 50%, #8B5CF6 100%)",
          boxShadow: "0 0 60px rgba(99,102,241,0.7), 0 0 120px rgba(99,102,241,0.3)",
          fontSize: 60,
        }}>⚡</div>

        {/* App name */}
        <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 10 }}>
          <div style={{ display: "flex", fontSize: 56, fontWeight: "bold", color: "white", letterSpacing: -2 }}>
            CryptoMind AI
          </div>
          <div style={{ display: "flex", fontSize: 22, color: "rgba(165,180,252,0.7)", letterSpacing: 3 }}>
            ASK ANYTHING
          </div>
        </div>

        {/* Divider line */}
        <div style={{ display: "flex", width: 80, height: 2, borderRadius: 2, background: "linear-gradient(90deg, transparent, rgba(99,102,241,0.6), transparent)" }} />

        {/* Tagline */}
        <div style={{ display: "flex", fontSize: 20, color: "rgba(255,255,255,0.45)", letterSpacing: 0.5 }}>
          Crypto · Portfolio · Alerts · Coding
        </div>

      </div>
    </div>,
  );
}
